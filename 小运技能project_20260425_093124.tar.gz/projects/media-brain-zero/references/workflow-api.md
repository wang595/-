# 外部能力接口规范

## 目录

- [前置依赖](#前置依赖)
- [蚁小二技能接口](#蚁小二技能接口)
  - [accounts](#accounts)
  - [account-overviews](#account-overviews)
  - [content-overviews](#content-overviews)
  - [records](#records)
  - [details](#details)
  - [publish](#publish)
  - [upload](#upload)
  - [hot-events](#hot-events)
- [自制子技能接口](#自制子技能接口)
  - [content-planner](#content-planner)
  - [text-generator](#text-generator)
  - [image-generator](#image-generator)
  - [video-generator](#video-generator)
  - [content-auditor](#content-auditor)
- [通用错误码](#通用错误码)

## 前置依赖

本 Skill 依赖蚁小二技能（https://github.com/yixiaoer888/yixiaoer-skill）提供平台操作能力。**必须先安装并配置蚁小二技能**，否则所有平台管理相关操作无法执行。

蚁小二技能统一调用方式：
```bash
node scripts/api.ts --payload='{"action":"xxx",...}'
```

环境变量要求：
- `YIXIAOER_API_KEY`：蚁小二API密钥（必填）
- `YIXIAOER_API_URL`：蚁小二API地址（可选，默认使用官方地址）

## 蚁小二技能接口

### accounts

查询蚁小二已绑定的全部账号。

**调用时机**
- Skill 首次初始化时
- 每日09:00早安巡检
- 用户主动要求刷新账号列表时

**请求参数**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `action` | string | 是 | 固定值：`accounts` |
| `platform` | string | 否 | 指定展示某个平台 |
| `name` | string | 否 | 按账号昵称模糊查询 |
| `group` | string | 否 | 按分组名称查询 |
| `page` | number | 否 | 当前页码，默认1 |
| `size` | number | 否 | 每页数量，默认20，最大1000 |
| `loginStatus` | number | 否 | 登录状态：0未登录/1成功/2过期 |

**调用示例**
```bash
node scripts/api.ts --payload='{"action":"accounts","platform":"抖音","page":1,"size":20}'
```

**响应字段**（关键字段）

| 字段 | 类型 | 说明 |
|------|------|------|
| `id` | string | 平台内部账号ID |
| `platformAccountName` | string | 账号昵称 |
| `platformName` | string | 平台名称（如：抖音、小红书） |
| `platformAuthorId` | string | 平台方UID/作者ID |
| `status` | number | 登录状态：1正常/2过期/3失败/4取消授权 |
| `groups` | string[] | 账号所属分组ID列表 |
| `isOperate` | boolean | 当前用户是否拥有运营权限 |

**异常处理**
- `status` 不为1时，记录异常账号并通知用户重新授权
- 返回空数组时，提示用户先绑定蚁小二账号

---

### account-overviews

获取账号综合数据概览，用于账号矩阵的权重分析、整体粉丝量监控及核心指标汇总。

**调用时机**
- 每日18:00数据收割
- 周报生成时
- 策略复盘时

**请求参数**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `action` | string | 是 | 固定值：`account-overviews` |
| `platform` | string | 是 | 指定查询某个平台 |
| `name` | string | 否 | 按账号昵称模糊查询 |
| `group` | string | 否 | 按分组名称查询 |
| `page` | number | 否 | 当前页码，默认1 |
| `size` | number | 否 | 每页数量，默认10 |

**调用示例**
```bash
node scripts/api.ts --payload='{"action":"account-overviews","platform":"抖音","page":1,"size":10}'
```

**响应字段**（关键字段）

| 字段 | 类型 | 说明 |
|------|------|------|
| `platformAccountId` | string | 媒体账号ID |
| `platformAccountName` | string | 账号昵称 |
| `overviewData` | object | 统计数据总计，包含 `fansTotal`, `playTotal`, `commentsTotal`, `likesTotal` 等 |

---

### content-overviews

获取已发布作品的数据统计信息，用于内容效果分析。

**调用时机**
- 内容效果复盘
- 诊断账号内容表现时
- 周报生成时

**请求参数**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `action` | string | 是 | 固定值：`content-overviews` |
| `platform` | string | 否 | 指定查询某个平台 |
| `platformAccountId` | string | 否 | 媒体账号ID |
| `type` | string | 否 | 作品类型：`article`(文章)/`video`(视频)/`miniVideo`(短视频)/`dynamic`(动态) |
| `publishStartTime` | number | 否 | 发布时间范围开始（Unix时间戳，毫秒） |
| `publishEndTime` | number | 否 | 发布时间范围结束（Unix时间戳，毫秒） |
| `page` | number | 否 | 当前页码，默认1 |
| `size` | number | 否 | 每页数量，默认10 |

**调用示例**
```bash
node scripts/api.ts --payload='{"action":"content-overviews","platform":"抖音","page":1,"size":10}'
```

**响应字段**（关键字段）

| 字段 | 类型 | 说明 |
|------|------|------|
| `platformAccountId` | string | 媒体账号ID |
| `accountName` | string | 账号昵称 |
| `contentData` | object | 原始统计数据，包含 `reCommand`(推荐), `play`(播放), `read`(阅读), `great`(点赞), `comment`(评论), `share`(分享), `collect`(收藏) 等 |

---

### records

查询发布历史记录（任务集概览），支持按平台、状态、时间等维度筛选。

**调用时机**
- 复盘分析时
- 确认发布任务状态时
- 周报生成时

**请求参数**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `action` | string | 是 | 固定值：`records` |
| `platforms` | string[] | 否 | 平台过滤 |
| `status` | number[] | 否 | 状态过滤：0发布中/1成功/2失败/3已取消/4待审核 |
| `keyword` | string | 否 | 标题关键词模糊搜索 |
| `start_time` | number | 否 | 开始时间戳（Unix ms） |
| `end_time` | number | 否 | 结束时间戳（Unix ms） |
| `page` | number | 否 | 分页，默认1 |
| `size` | number | 否 | 每页数量，默认20 |

**调用示例**
```bash
node scripts/api.ts --payload='{"action":"records","status":[1,2],"page":1}'
```

---

### details

查询发布任务详情，用于失败排查。

**调用时机**
- 发布失败后排查原因
- 用户要求查看某条发布详情时

**请求参数**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `action` | string | 是 | 固定值：`details` |
| `task_set_id` | string | 是 | 任务集ID |

---

### publish

向指定账号发布内容。发布前必须先调用 `upload` 上传媒体资源。

**调用时机**
- 内容日历执行阶段
- 用户要求紧急发布时

**请求参数**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `action` | string | 是 | 固定值：`publish` |
| `accounts` | string[] | 是 | 目标账号ID数组 |
| `type` | string | 是 | 发布类型：`video`(视频)/`article`(文章)/`image-text`(图文) |
| `title` | string | 是 | 内容标题 |
| `content` | string | 是 | 正文内容 |
| `coverKey` | string | 否 | 封面图key（upload接口返回） |
| `video.key` | string | 视频类必填 | 视频key（upload接口返回） |
| `publishTime` | number | 否 | 定时发布时间（Unix时间戳，毫秒），不传则立即发布 |
| `category` | string | 否 | 内容分类 |
| `tags` | string[] | 否 | 话题标签 |

**重要约束**
- 封面图、图文图片、视频文件严禁直接使用外部URL，必须通过 `upload` 接口获取key
- 不同平台的额外参数见蚁小二技能 `docs/publish/` 下各平台文档

**调用示例**
```bash
node scripts/api.ts --payload='{"action":"publish","accounts":["id1","id2"],"type":"video","title":"标题","content":"正文","coverKey":"xxx","video":{"key":"xxx"}}'
```

---

### upload

上传图片、视频到蚁小二OSS，获取用于发布的资源key。

**调用时机**
- 发布前置（必须先传再发）
- 用户上传素材时

**请求参数**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `action` | string | 是 | 固定值：`upload` |
| `url` | string | 是 | 资源的远程URL或本地绝对路径 |
| `bucket` | string | 否 | OSS存储桶，`cloud-publish`(默认) 或 `material-library`(素材库) |
| `contentType` | string | 是 | MIME类型，如 `video/mp4`, `image/png` |
| `size` | number | 否 | 资源大小（字节） |

**调用示例**
```bash
node scripts/api.ts --payload='{"action":"upload","url":"https://example.com/image.jpg","bucket":"cloud-publish","contentType":"image/jpeg"}'
```

**响应字段**

| 字段 | 类型 | 说明 |
|------|------|------|
| `key` | string | 资源标识，如 `cloud-publish/2026/03/26/xxx/xxx.jpg` |
| `name` | string | 文件名 |
| `bucket` | string | 存储桶 |

---

### hot-events

获取平台实时热点列表，用于绑定到内容以提升曝光。

**调用时机**
- 每日12:00热点响应
- 每周内容规划时

**请求参数**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `action` | string | 是 | 固定值：`hot-events` |
| `account_id` | string | 是 | 账号ID（用于获取该账号所在平台的热点） |

**调用示例**
```bash
node scripts/api.ts --payload='{"action":"hot-events","account_id":"YOUR_ACCOUNT_ID"}'
```

## 自制子技能接口

以下子技能由开发者自行实现，通过 Coze 工作流或子技能镶嵌到本 Skill 中。统一遵循以下规范。

### 统一规范

**请求格式**：
```json
{
  "action": "子技能名称",
  "params": { ... }
}
```

**响应格式**：
```json
{
  "status": "success|error",
  "data": { ... },
  "message": "错误时填写原因",
  "retryable": true|false
}
```

### content-planner

**职责**：小运的"策划部"——决定今天发什么、从什么角度切入、用什么形式。

**输入参数**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `action` | string | 是 | 固定值：`content-planner` |
| `account_id` | string | 否 | 指定账号，不传则默认全部 |
| `hotspots` | array | 否 | 当前热点列表，每项包含 title, platform, heat_score |
| `strategy` | string | 否 | 当前运营策略描述 |
| `count` | number | 否 | 规划条数，默认7 |

**输出字段**

| 字段 | 类型 | 说明 |
|------|------|------|
| `plans` | array | 规划数组，每项包含 topic, angle, format, platform, priority, expected_engagement |

**调用示例**
```json
{
  "action": "content-planner",
  "params": {
    "account_id": "douyin_123",
    "hotspots": [{"title": "春季穿搭", "platform": "小红书", "heat_score": 95}],
    "strategy": "种草+转化",
    "count": 3
  }
}
```

**错误处理**：生成失败返回500（retryable=true）

---

### text-generator

**职责**：小运的"文案部"——写标题和正文，适配不同平台调性。

**输入参数**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `action` | string | 是 | 固定值：`text-generator` |
| `topic` | string | 是 | 选题主题 |
| `platform` | string | 是 | 目标平台（抖音/小红书/视频号等） |
| `style` | string | 否 | 文案风格（幽默/专业/故事化/口播/种草等） |
| `length` | string | 否 | 篇幅：short(100字内)/medium(300-500字)/long(800字+) |
| `reference_cases` | string[] | 否 | 参考案例文案 |

**输出字段**

| 字段 | 类型 | 说明 |
|------|------|------|
| `title` | string | 生成的标题 |
| `content` | string | 生成的正文 |
| `suggested_tags` | string[] | 推荐话题标签 |

**调用示例**
```json
{
  "action": "text-generator",
  "params": {
    "topic": "春季穿搭",
    "platform": "小红书",
    "style": "种草",
    "length": "medium"
  }
}
```

**错误处理**：生成失败返回500（retryable=true）

---

### image-generator

**职责**：小运的"设计部"——做封面图、插图、海报。

**输入参数**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `action` | string | 是 | 固定值：`image-generator` |
| `prompt` | string | 是 | 图片描述（支持中文） |
| `style` | string | 否 | 风格（写实/插画/海报/3D/扁平/中国风等） |
| `size` | string | 否 | 尺寸，如"1080x1920"（抖音竖版）、"1242x1660"（小红书） |
| `text_overlay` | string | 否 | 图上需要叠加的文字（如标题） |

**输出字段**

| 字段 | 类型 | 说明 |
|------|------|------|
| `image_url` | string | 图片访问地址（可直接用于 upload 接口上传） |

**调用示例**
```json
{
  "action": "image-generator",
  "params": {
    "prompt": "一位年轻女性在春日花园里穿着米色风衣，背景是樱花",
    "style": "写实",
    "size": "1080x1920",
    "text_overlay": "春季穿搭指南"
  }
}
```

**错误处理**：生成失败返回500（retryable=true）

---

### video-generator

**职责**：小运的"视频部"——把文案转成视频（口播/混剪/动画）。

**输入参数**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `action` | string | 是 | 固定值：`video-generator` |
| `script` | string | 是 | 视频脚本/分镜描述 |
| `style` | string | 否 | 风格（口播/混剪/动画/图文轮播等） |
| `duration` | number | 否 | 时长（秒），默认30 |
| `media_refs` | string[] | 否 | 素材参考URL（图片/视频片段） |
| `voice_style` | string | 否 | 配音风格（男声/女声/方言/激昂/温和等） |

**输出字段**

| 字段 | 类型 | 说明 |
|------|------|------|
| `video_url` | string | 视频访问地址 |
| `thumbnail_url` | string | 自动生成的封面图地址 |

**调用示例**
```json
{
  "action": "video-generator",
  "params": {
    "script": "开场：一位女生站在镜子前...",
    "style": "口播",
    "duration": 45,
    "voice_style": "女声"
  }
}
```

**错误处理**：生成失败返回500（retryable=true）

---

### content-auditor

**职责**：小运的"风控部"——检查内容有没有违禁词、图片违不违规、标题有没有误导。

**输入参数**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `action` | string | 是 | 固定值：`content-auditor` |
| `title` | string | 是 | 内容标题 |
| `content` | string | 是 | 正文内容 |
| `platform` | string | 是 | 目标平台 |
| `media_urls` | string[] | 否 | 配图/视频地址 |

**输出字段**

| 字段 | 类型 | 说明 |
|------|------|------|
| `passed` | boolean | 是否通过审核 |
| `violations` | array | 违规项数组，每项包含 type 和 description |
| `suggestions` | string[] | 修改建议 |

**调用示例**
```json
{
  "action": "content-auditor",
  "params": {
    "title": "春季穿搭指南",
    "content": "正文内容...",
    "platform": "小红书",
    "media_urls": ["https://..."]
  }
}
```

**错误处理**：返回 passed=false 时，violations 必须非空

## 通用错误码

| 错误码 | 含义 | 处理建议 |
|--------|------|----------|
| 400 | 请求参数错误 | 检查必填参数是否齐全 |
| 401 | 账号未登录/授权过期 | 通知用户重新授权，标记到 pending_failures |
| 403 | 内容违规 | 通知用户违规原因，标记到 pending_failures |
| 404 | 账号/内容不存在 | 刷新账号列表后重试 |
| 429 | 限流 | retryable=true，延迟后重试 |
| 500 | 服务端错误 | retryable=true，稍后重试 |
| 503 | 服务不可用 | retryable=true，稍后重试 |
