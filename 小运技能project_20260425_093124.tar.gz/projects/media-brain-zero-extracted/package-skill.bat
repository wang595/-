@echo off
chcp 65001 >nul
echo ============================================
echo    Media Brain Zero - 技能打包工具
echo ============================================
echo.

set SKILL_DIR=%~dp0
set SKILL_NAME=media-brain-zero
set OUTPUT_DIR=%USERPROFILE%\Desktop

echo 📦 正在打包技能...
echo.

REM 使用 PowerShell 压缩
powershell -Command "Compress-Archive -Path '%SKILL_DIR%*' -DestinationPath '%OUTPUT_DIR%\%SKILL_NAME%-v2.1.0.zip' -Force"

if %errorlevel% equ 0 (
    echo.
    echo ✅ 打包完成！
    echo 📁 文件位置：%OUTPUT_DIR%\%SKILL_NAME%-v2.1.0.zip
    echo.
    echo ============================================
    echo    使用说明
    echo ============================================
    echo.
    echo 1. 解压 zip 文件到：
    echo    C:\Users\[你的用户名]\.workbuddy\skills\
    echo.
    echo 2. 重启 WorkBuddy
    echo.
    echo 3. 在聊天框输入：
    echo    启动 Media Brain Zero
    echo.
    echo ============================================
) else (
    echo.
    echo ❌ 打包失败
    echo.
)

pause
