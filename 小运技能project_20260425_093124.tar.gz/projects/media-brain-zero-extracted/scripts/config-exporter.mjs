#!/usr/bin/env node
/**
 * Media Brain Zero - 配置管理器
 * 功能：读写配置文件和记忆数据
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT_DIR = join(__dirname, '..');
const DATA_DIR = join(ROOT_DIR, 'data');

// 确保数据目录存在
mkdirSync(DATA_DIR, { recursive: true });

const CONFIG_PATH = join(DATA_DIR, 'config.json');
const MEMORY_PATH = join(DATA_DIR, 'memory.json');
const ACCOUNTS_PATH = join(DATA_DIR, 'accounts.json');
const PLANS_PATH = join(DATA_DIR, 'plans.json');

// 日志
function log(message, type = 'INFO') {
  const prefix = { INFO: '💾', SUCCESS: '✅', WARN: '⚠️', ERROR: '❌' }[type] || '📝';
  console.log(`${prefix} [Config] ${message}`);
}

// 默认配置
const DEFAULT_CONFIG = {
  mode: 'zero',
  version: '1.0.0',
  autoDetect: true,
  browser: 'auto',
  notifications: {
    daily: true,
    error: true,
    WeChat: false,
    email: false
  },
  publish: {
    maxDaily: 3,
    preferredTime: '18:00',
    hotspot: true,
    retryCount: 3,
    retryDelay: 300 // 秒
  },
  content: {
    style: 'professional',
    length: 'medium',
    emoji: true,
    hashtags: true
  },
  ai: {
    provider: 'deepseek',
    model: 'deepseek-chat',
    temperature: 0.7
  },
  setup: {
    completed: false,
    setupDate: null,
    yixiaoerLinked: false,
    accountsLinked: 0
  },
  schedule: {
    enabled: true,
    times: ['08:00', '12:00', '18:00'],
    timezone: 'Asia/Shanghai'
  }
};

// 默认记忆模板
const DEFAULT_MEMORY = {
  createdAt: new Date().toISOString(),
  lastRun: null,
  totalRuns: 0,
  publishHistory: [],
  contentBank: [],
  learnings: [],
  errors: []
};

// ============ 配置管理 ============

export function getDefaultConfig() {
  return { ...DEFAULT_CONFIG };
}

export function loadConfig() {
  try {
    if (existsSync(CONFIG_PATH)) {
      const data = readFileSync(CONFIG_PATH, 'utf-8');
      const config = JSON.parse(data);
      // 合并默认配置，确保新字段存在
      return { ...DEFAULT_CONFIG, ...config };
    }
  } catch (error) {
    log(`加载配置失败: ${error.message}`, 'ERROR');
  }
  return { ...DEFAULT_CONFIG };
}

export function saveConfig(config) {
  try {
    writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
    log('配置已保存', 'SUCCESS');
    return true;
  } catch (error) {
    log(`保存配置失败: ${error.message}`, 'ERROR');
    return false;
  }
}

export function updateConfig(updates) {
  const config = loadConfig();
  const newConfig = { ...config, ...updates };
  return saveConfig(newConfig);
}

export function resetConfig() {
  return saveConfig(DEFAULT_CONFIG);
}

// ============ 记忆管理 ============

export function loadMemory() {
  try {
    if (existsSync(MEMORY_PATH)) {
      const data = readFileSync(MEMORY_PATH, 'utf-8');
      return JSON.parse(data);
    }
  } catch (error) {
    log(`加载记忆失败: ${error.message}`, 'ERROR');
  }
  return { ...DEFAULT_MEMORY };
}

export function saveMemory(memory) {
  try {
    writeFileSync(MEMORY_PATH, JSON.stringify(memory, null, 2));
    return true;
  } catch (error) {
    log(`保存记忆失败: ${error.message}`, 'ERROR');
    return false;
  }
}

export function updateMemory(key, value) {
  const memory = loadMemory();
  memory[key] = value;
  memory.lastUpdated = new Date().toISOString();
  return saveMemory(memory);
}

export function appendToMemory(key, item) {
  const memory = loadMemory();
  if (!memory[key]) {
    memory[key] = [];
  }
  if (Array.isArray(memory[key])) {
    memory[key].push(item);
  }
  memory.lastUpdated = new Date().toISOString();
  return saveMemory(memory);
}

// ============ 账号管理 ============

export function loadAccounts() {
  try {
    if (existsSync(ACCOUNTS_PATH)) {
      const data = readFileSync(ACCOUNTS_PATH, 'utf-8');
      return JSON.parse(data);
    }
  } catch (error) {
    log(`加载账号失败: ${error.message}`, 'ERROR');
  }
  return [];
}

export function saveAccounts(accounts) {
  try {
    writeFileSync(ACCOUNTS_PATH, JSON.stringify(accounts, null, 2));
    log(`已保存 ${accounts.length} 个账号`, 'SUCCESS');
    return true;
  } catch (error) {
    log(`保存账号失败: ${error.message}`, 'ERROR');
    return false;
  }
}

export function addAccount(account) {
  const accounts = loadAccounts();
  const exists = accounts.find(a => a.id === account.id);
  if (!exists) {
    accounts.push(account);
    return saveAccounts(accounts);
  }
  return false;
}

export function removeAccount(accountId) {
  const accounts = loadAccounts();
  const filtered = accounts.filter(a => a.id !== accountId);
  return saveAccounts(filtered);
}

export function updateAccount(accountId, updates) {
  const accounts = loadAccounts();
  const idx = accounts.findIndex(a => a.id === accountId);
  if (idx >= 0) {
    accounts[idx] = { ...accounts[idx], ...updates };
    return saveAccounts(accounts);
  }
  return false;
}

// ============ 方案管理 ============

export function loadPlans() {
  try {
    if (existsSync(PLANS_PATH)) {
      const data = readFileSync(PLANS_PATH, 'utf-8');
      return JSON.parse(data);
    }
  } catch (error) {
    log(`加载方案失败: ${error.message}`, 'ERROR');
  }
  return [];
}

export function savePlans(plans) {
  try {
    writeFileSync(PLANS_PATH, JSON.stringify(plans, null, 2));
    log(`已保存 ${plans.length} 个方案`, 'SUCCESS');
    return true;
  } catch (error) {
    log(`保存方案失败: ${error.message}`, 'ERROR');
    return false;
  }
}

export function getPlanByAccountId(accountId) {
  const plans = loadPlans();
  return plans.find(p => p.accountId === accountId);
}

export function updatePlan(accountId, planUpdates) {
  const plans = loadPlans();
  const idx = plans.findIndex(p => p.accountId === accountId);
  if (idx >= 0) {
    plans[idx] = { ...plans[idx], ...planUpdates, updatedAt: new Date().toISOString() };
  } else {
    plans.push({ accountId, ...planUpdates, createdAt: new Date().toISOString() });
  }
  return savePlans(plans);
}

// ============ 导出/导入 ============

export function exportAllData() {
  return {
    config: loadConfig(),
    accounts: loadAccounts(),
    plans: loadPlans(),
    memory: loadMemory(),
    exportedAt: new Date().toISOString()
  };
}

export function importAllData(data) {
  if (data.config) saveConfig(data.config);
  if (data.accounts) saveAccounts(data.accounts);
  if (data.plans) savePlans(data.plans);
  if (data.memory) saveMemory(data.memory);
  return true;
}

export function clearAllData() {
  try {
    if (existsSync(CONFIG_PATH)) require('fs').unlinkSync(CONFIG_PATH);
    if (existsSync(MEMORY_PATH)) require('fs').unlinkSync(MEMORY_PATH);
    if (existsSync(ACCOUNTS_PATH)) require('fs').unlinkSync(ACCOUNTS_PATH);
    if (existsSync(PLANS_PATH)) require('fs').unlinkSync(PLANS_PATH);
    log('所有数据已清除', 'SUCCESS');
    return true;
  } catch (error) {
    log(`清除数据失败: ${error.message}`, 'ERROR');
    return false;
  }
}

// ============ 状态检查 ============

export function getSystemStatus() {
  const config = loadConfig();
  const accounts = loadAccounts();
  const plans = loadPlans();
  const memory = loadMemory();
  
  return {
    initialized: config.setup?.completed || false,
    yixiaoerLinked: config.setup?.yixiaoerLinked || false,
    accountsLinked: accounts.length,
    plansGenerated: plans.length,
    totalPublishes: memory.publishHistory?.length || 0,
    lastRun: memory.lastRun,
    uptime: memory.totalRuns || 0
  };
}

// 默认导出
export default {
  // 配置
  getDefaultConfig,
  loadConfig,
  saveConfig,
  updateConfig,
  resetConfig,
  
  // 记忆
  loadMemory,
  saveMemory,
  updateMemory,
  appendToMemory,
  
  // 账号
  loadAccounts,
  saveAccounts,
  addAccount,
  removeAccount,
  updateAccount,
  
  // 方案
  loadPlans,
  savePlans,
  getPlanByAccountId,
  updatePlan,
  
  // 导出导入
  exportAllData,
  importAllData,
  clearAllData,
  
  // 状态
  getSystemStatus
};
