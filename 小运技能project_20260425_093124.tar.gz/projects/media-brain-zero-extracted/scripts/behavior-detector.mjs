#!/usr/bin/env node
/**
 * Media Brain Zero - 用户行为检测与自动纠正
 * 
 * 功能：
 * - 检测用户素材是否放错位置
 * - 自动整理并告知用户
 * - 记录使用习惯，持续优化
 * 
 * 作者：洞察 (Dongcha)
 * 日期：2026-04-08
 */

import fs from 'fs/promises';
import path from 'path';
import os from 'os';

const __dirname = path.dirname(new URL(import.meta.url).pathname);
const DESKTOP_PATH = path.join('C:', 'Users', os.userInfo().username, 'Desktop');

// 素材分类规则
const MATERIAL_CATEGORIES = {
  '厂区': '🏭企业素材/厂区环境',
  '工厂': '🏭企业素材/厂区环境',
  '车间': '🏭企业素材/厂区环境',
  '产品': '🏭企业素材/产品展示',
  '商品': '🏭企业素材/产品展示',
  '团队': '🏭企业素材/团队风采',
  '员工': '🏭企业素材/团队风采',
  '办公': '🏭企业素材/团队风采',
  '资质': '🏭企业素材/其他',
  '证书': '🏭企业素材/其他',
  '客户': '🏭企业素材/其他',
  '案例': '🏭企业素材/其他',
  'logo': '🏭企业素材/其他',
  '封面': '📥待发布内容/封面图',
  '配图': '📥待发布内容/配图',
  '视频': '📥待发布内容',
  'movie': '📥待发布内容',
  'clip': '📥待发布内容',
  'AI': '📥待发布内容',  // AI生成的
  '生成': '📥待发布内容'  // AI生成的
};

// 常见错误位置
const WRONG_LOCATIONS = [
  '下载', 'Downloads', 'download',
  '桌面', 'Desktop', 'desktop',
  '文档', 'Documents', 'documents',
  '图片', 'Pictures', 'pictures',
  '截图', 'Screenshots', 'screenshots'
];

/**
 * 检测文件/文件夹是否在正确位置
 */
export async function checkMaterialLocation(filePath, targetAccountLib) {
  const normalizedPath = filePath.toLowerCase();
  const wrongLocations = WRONG_LOCATIONS.map(l => l.toLowerCase());
  
  // 检查是否在错误位置
  for (const wrong of wrongLocations) {
    if (normalizedPath.includes(wrong)) {
      return {
        correct: false,
        reason: '位置错误',
        suggestion: `这个文件似乎在"${path.basename(filePath)}"文件夹里，应该放到账号素材库中`
      };
    }
  }
  
  // 检查是否在正确的账号素材库中
  if (normalizedPath.includes(targetAccountLib.toLowerCase())) {
    return { correct: true };
  }
  
  // 检查是否在其他账号素材库
  if (normalizedPath.includes('新媒体素材库')) {
    return {
      correct: false,
      reason: '位置错误',
      suggestion: '这个文件放到了其他账号的素材库里'
    };
  }
  
  return {
    correct: false,
    reason: '位置不明',
    suggestion: '建议放到账号专属素材库中'
  };
}

/**
 * 智能判断素材类型
 */
export function classifyMaterial(filename) {
  const lowerName = filename.toLowerCase();
  
  for (const [keyword, category] of Object.entries(MATERIAL_CATEGORIES)) {
    if (lowerName.includes(keyword.toLowerCase())) {
      return category;
    }
  }
  
  // 默认分类（根据扩展名）
  const ext = path.extname(filename).toLowerCase();
  if (['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'].includes(ext)) {
    return '🏭企业素材/其他'; // 图片默认归入企业素材
  }
  if (['.mp4', '.mov', '.avi', '.mkv', '.webm'].includes(ext)) {
    return '📥待发布内容'; // 视频归入待发布
  }
  if (['.doc', '.docx', '.pdf', '.txt', '.md'].includes(ext)) {
    return '📥待发布内容/文案脚本'; // 文档归入文案脚本
  }
  
  return '🏭企业素材/其他'; // 其他默认归入企业素材
}

/**
 * 扫描桌面下载文件夹中的新素材
 */
export async function scanForNewMaterials() {
  const results = [];
  
  // 扫描常见位置
  const scanPaths = [
    path.join(DESKTOP_PATH),           // 桌面
    path.join(DESKTOP_PATH, '下载'),   // 中文下载
    path.join(DESKTOP_PATH, 'Downloads'),
    path.join('C:', 'Users', os.userInfo().username, 'Downloads')
  ];
  
  for (const scanPath of scanPaths) {
    try {
      const entries = await fs.readdir(scanPath, { withFileTypes: true });
      
      for (const entry of entries) {
        const fullPath = path.join(scanPath, entry.name);
        
        // 只关注最近修改的文件（24小时内）
        const stats = await fs.stat(fullPath);
        const hoursOld = (Date.now() - stats.mtimeMs) / (1000 * 60 * 60);
        
        if (hoursOld > 24) continue; // 跳过太旧的
        
        // 检查是否是素材类型
        const ext = path.extname(entry.name).toLowerCase();
        const isMedia = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.mp4', '.mov', '.avi'].includes(ext);
        const isDocument = ['.doc', '.docx', '.pdf', '.txt', '.md'].includes(ext);
        
        if (isMedia || isDocument || entry.name.includes('素材') || entry.name.includes('图片')) {
          results.push({
            path: fullPath,
            name: entry.name,
            type: isMedia ? 'media' : 'document',
            detectedCategory: classifyMaterial(entry.name),
            modifiedAt: stats.mtime,
            suggestedAction: '移动到素材库'
          });
        }
      }
    } catch (e) {
      // 忽略无法访问的目录
    }
  }
  
  return results;
}

/**
 * 主动检测并整理素材
 */
export async function autoOrganizeMaterials(accountConfig) {
  const { name: accountName } = accountConfig;
  const targetLib = `新媒体素材库/${accountName}的专属素材库`;
  
  // 扫描新素材
  const newMaterials = await scanForNewMaterials();
  
  if (newMaterials.length === 0) {
    return {
      found: false,
      message: '未检测到新素材'
    };
  }
  
  const toMove = [];
  const report = [];
  
  for (const material of newMaterials) {
    // 检查是否已经在正确的位置
    if (material.path.includes(targetLib)) {
      continue;
    }
    
    // 智能分类
    const targetCategory = material.detectedCategory;
    const targetPath = path.join(DESKTOP_PATH, targetLib, targetCategory);
    
    toMove.push({
      from: material.path,
      to: targetPath,
      name: material.name,
      category: targetCategory
    });
    
    report.push({
      name: material.name,
      from: path.basename(path.dirname(material.path)),
      to: targetCategory,
      reason: classifyReason(material.name)
    });
  }
  
  if (report.length === 0) {
    return {
      found: false,
      message: '素材位置都正确'
    };
  }
  
  // 执行移动
  for (const item of toMove) {
    try {
      // 确保目标目录存在
      await fs.mkdir(item.to, { recursive: true });
      
      // 移动文件
      const destPath = path.join(item.to, item.name);
      await fs.rename(item.from, destPath);
    } catch (e) {
      // 如果移动失败（比如同名文件存在），尝试重命名
      try {
        const destPath = path.join(item.to, `备份_${item.name}`);
        await fs.rename(item.from, destPath);
      } catch (e2) {
        // 忽略
      }
    }
  }
  
  return {
    found: true,
    count: report.length,
    report,
    message: generateReportMessage(report, accountName)
  };
}

/**
 * 生成整理报告
 */
function generateReportMessage(report, accountName) {
  if (report.length === 0) return '';
  
  let message = `\n🔍 我帮您整理了 ${report.length} 个文件：\n\n`;
  
  for (const item of report) {
    message += `📦 ${item.name}\n`;
    message += `   📍 从「${item.from}」移动到「${item.to}」\n`;
    message += `   💡 ${item.reason}\n\n`;
  }
  
  message += `✅ 已全部整理到「${accountName}的专属素材库」\n`;
  message += `   您可以直接在桌面找到这个文件夹\n`;
  
  return message;
}

/**
 * 判断分类原因
 */
function classifyReason(filename) {
  const lowerName = filename.toLowerCase();
  
  if (lowerName.includes('厂区') || lowerName.includes('工厂') || lowerName.includes('车间')) {
    return '我识别到这是厂区/工厂相关的图片，归类到"企业素材/厂区环境"';
  }
  if (lowerName.includes('产品') || lowerName.includes('商品')) {
    return '我识别到这是产品相关的图片，归类到"企业素材/产品展示"';
  }
  if (lowerName.includes('团队') || lowerName.includes('员工') || lowerName.includes('办公')) {
    return '我识别到这是团队相关的图片，归类到"企业素材/团队风采"';
  }
  if (lowerName.includes('封面')) {
    return '我识别到这是封面图，归类到"待发布内容/封面图"';
  }
  if (lowerName.includes('视频') || lowerName.includes('movie')) {
    return '我识别到这是视频素材，归类到"待发布内容"';
  }
  
  return '根据文件名特征归类到了合适的位置';
}

/**
 * 记录用户反馈
 */
export async function recordUserFeedback(feedback) {
  const feedbackPath = path.join(__dirname, '..', 'data', 'user-feedback.json');
  
  let feedbackList = [];
  try {
    const existing = await fs.readFile(feedbackPath, 'utf8');
    feedbackList = JSON.parse(existing);
  } catch (e) {
    // 文件不存在，忽略
  }
  
  feedbackList.push({
    ...feedback,
    timestamp: new Date().toISOString()
  });
  
  // 只保留最近100条
  if (feedbackList.length > 100) {
    feedbackList = feedbackList.slice(-100);
  }
  
  await fs.writeFile(feedbackPath, JSON.stringify(feedbackList, null, 2));
}

/**
 * 从用户反馈中学习
 */
export async function learnFromFeedback() {
  const feedbackPath = path.join(__dirname, '..', 'data', 'user-feedback.json');
  
  try {
    const data = await fs.readFile(feedbackPath, 'utf8');
    const feedbackList = JSON.parse(data);
    
    // 分析反馈模式
    const corrections = feedbackList.filter(f => f.type === 'correction');
    
    if (corrections.length === 0) return null;
    
    // 返回学习结果
    return {
      totalFeedback: feedbackList.length,
      corrections: corrections.length,
      patterns: analyzePatterns(corrections)
    };
  } catch (e) {
    return null;
  }
}

function analyzePatterns(corrections) {
  // 简单分析：如果用户经常纠正某类素材的分类，记录下来
  const patterns = {};
  
  for (const c of corrections) {
    if (c.from && c.to) {
      const key = `${c.from}->${c.to}`;
      patterns[key] = (patterns[key] || 0) + 1;
    }
  }
  
  return patterns;
}

export default {
  checkMaterialLocation,
  classifyMaterial,
  scanForNewMaterials,
  autoOrganizeMaterials,
  recordUserFeedback,
  learnFromFeedback
};
