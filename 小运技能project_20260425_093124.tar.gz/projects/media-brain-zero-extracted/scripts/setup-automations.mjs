#!/usr/bin/env node
/**
 * Media Brain Zero - 自动化任务设置器
 * 功能：创建定时任务（心跳监控、账号扫描）
 */

import { exec, spawn } from 'child_process';
import { promisify } from 'util';
import { existsSync, mkdirSync, writeFileSync, readFileSync, readdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const execAsync = promisify(exec);

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT_DIR = join(__dirname, '..');
const DATA_DIR = join(ROOT_DIR, 'data');
const TASKS_DIR = join(DATA_DIR, 'tasks');

// 确保目录存在
mkdirSync(TASKS_DIR, { recursive: true });

// 日志
function log(message, type = 'INFO') {
  const prefix = {
    'INFO': '📋',
    'SUCCESS': '✅',
    'WARN': '⚠️',
    'ERROR': '❌',
    'TASK': '🔄'
  }[type] || '📝';
  console.log(`${prefix} [${type}] ${message}`);
}

// 获取桌面路径
function getDesktopPath() {
  const home = process.env.HOME || process.env.USERPROFILE;
  return join(home, 'Desktop');
}

// 为账号创建桌面文件夹
async function createAccountFolder(account) {
  const desktop = getDesktopPath();
  const folderName = `${account.name}的素材库`;
  const folderPath = join(desktop, folderName);
  
  const subFolders = [
    'AI生成内容',
    '企业素材',
    '封面图',
    '配图',
    '文案脚本',
    '已发布归档'
  ];
  
  try {
    // 创建主文件夹
    mkdirSync(folderPath, { recursive: true });
    log(`创建文件夹: ${folderName}`, 'SUCCESS');
    
    // 创建子文件夹
    for (const subFolder of subFolders) {
      mkdirSync(join(folderPath, subFolder), { recursive: true });
    }
    
    // 创建账号信息文件
    const accountInfo = {
      id: account.id,
      name: account.name,
      platform: account.platform,
      fans: account.fans || 0,
      createdAt: new Date().toISOString(),
      folders: subFolders
    };
    writeFileSync(
      join(folderPath, '账号信息.json'),
      JSON.stringify(accountInfo, null, 2)
    );
    
    // 创建 materials.json 素材索引
    writeFileSync(
      join(folderPath, 'materials.json'),
      JSON.stringify({ materials: [], lastUpdated: new Date().toISOString() }, null, 2)
    );
    
    log(`  └── 已创建 ${subFolders.length} 个子文件夹 + 素材索引`, 'SUCCESS');
    
    return { success: true, path: folderPath };
  } catch (error) {
    log(`创建文件夹失败: ${error.message}`, 'ERROR');
    return { success: false, error: error.message };
  }
}

// 为所有账号创建文件夹
async function createAllAccountFolders(accounts) {
  log(`开始为 ${accounts.length} 个账号创建素材库文件夹...`, 'TASK');
  
  const results = [];
  for (const account of accounts) {
    const result = await createAccountFolder(account);
    results.push({ account: account.name, ...result });
  }
  
  return results;
}

// 创建心跳监控任务（PowerShell脚本）
function createHeartbeatTaskScript() {
  const scriptContent = `@echo off
echo [%date% %time%] Media Brain Zero - 心跳监控开始
cd /d "${ROOT_DIR.replace(/\\/g, '\\\\')}"
node scripts/heartbeat-monitor.mjs >> logs/heartbeat.log 2>&1
echo [%date% %time%] 心跳监控完成
`;
  
  const scriptPath = join(TASKS_DIR, 'heartbeat-monitor.bat');
  writeFileSync(scriptPath, scriptContent);
  log('心跳监控脚本已创建', 'SUCCESS');
  return scriptPath;
}

// 创建账号扫描任务（PowerShell脚本）
function createScannerTaskScript() {
  const scriptContent = `@echo off
echo [%date% %time%] Media Brain Zero - 账号扫描开始
cd /d "${ROOT_DIR.replace(/\\/g, '\\\\')}"
node scripts/account-scanner.mjs >> logs/scanner.log 2>&1
echo [%date% %time%] 账号扫描完成
`;
  
  const scriptPath = join(TASKS_DIR, 'account-scanner.bat');
  writeFileSync(scriptPath, scriptContent);
  log('账号扫描脚本已创建', 'SUCCESS');
  return scriptPath;
}

// 使用 schtasks 创建 Windows 定时任务
async function createScheduledTask(taskName, scriptPath, schedule) {
  log(`创建定时任务: ${taskName} (每${schedule.interval}执行一次)`, 'TASK');
  
  const taskDescription = 'Media Brain Zero - 新媒体自动化运营';
  
  // 转换间隔为 Windows schtasks 格式
  let scheduleType = '/SC HOURLY';
  let modifier = '';
  
  if (schedule.unit === 'minutes') {
    scheduleType = '/SC MINUTE';
    modifier = `/MO ${schedule.interval}`;
  } else if (schedule.unit === 'hours') {
    scheduleType = '/SC HOURLY';
    modifier = `/MO ${schedule.interval}`;
  } else if (schedule.unit === 'daily') {
    scheduleType = '/SC DAILY';
    modifier = schedule.time ? `/ST ${schedule.time}` : '';
  }
  
  const command = `schtasks /Create /TN "${taskName}" /TR "${scriptPath}" ${scheduleType} ${modifier} /F`;
  
  try {
    await execAsync(command);
    log(`定时任务创建成功: ${taskName}`, 'SUCCESS');
    return { success: true, taskName };
  } catch (error) {
    // 如果 schtasks 失败，保存到任务列表（由主程序执行）
    log(`schtasks 创建失败，将保存为待创建任务: ${error.message}`, 'WARN');
    savePendingTask(taskName, scriptPath, schedule);
    return { success: false, error: error.message, taskName, scriptPath, schedule };
  }
}

// 保存待创建的任务
function savePendingTask(taskName, scriptPath, schedule) {
  const pendingPath = join(TASKS_DIR, 'pending-tasks.json');
  let pending = [];
  
  if (existsSync(pendingPath)) {
    try {
      pending = JSON.parse(readFileSync(pendingPath, 'utf-8'));
    } catch (e) {}
  }
  
  pending.push({ taskName, scriptPath, schedule, createdAt: new Date().toISOString() });
  writeFileSync(pendingPath, JSON.stringify(pending, null, 2));
  log(`已保存待创建任务: ${taskName}`, 'INFO');
}

// 创建所有定时任务
async function createAllScheduledTasks() {
  log('开始创建定时任务...', 'TASK');
  
  // 1. 心跳监控任务（每2小时）
  const heartbeatScript = createHeartbeatTaskScript();
  const heartbeatTask = await createScheduledTask(
    'MediaBrainZero_HeartbeatMonitor',
    heartbeatScript,
    { unit: 'hours', interval: 2 }
  );
  
  // 2. 账号扫描任务（每30分钟）
  const scannerScript = createScannerTaskScript();
  const scannerTask = await createScheduledTask(
    'MediaBrainZero_AccountScanner',
    scannerScript,
    { unit: 'minutes', interval: 30 }
  );
  
  return { heartbeatTask, scannerTask };
}

// 生成任务配置JSON（供 WorkBuddy 自动化使用）
function generateWorkBuddyAutomations() {
  const automations = [
    {
      name: 'Media Brain Zero - 新媒体心跳监控',
      prompt: '运行 C:/Users/wlb/.qoderwork/skills/media-brain-zero/scripts/heartbeat-monitor.mjs，监控所有账号状态、发布队列、素材库。检查是否有发布失败、账号异常、内容待发布等情况。如有异常，在桌面创建提醒文件。',
      scheduleType: 'recurring',
      rrule: 'FREQ=HOURLY;INTERVAL=2',
      status: 'ACTIVE'
    },
    {
      name: 'Media Brain Zero - 账号扫描',
      prompt: '运行 C:/Users/wlb/.qoderwork/skills/media-brain-zero/scripts/account-scanner.mjs，扫描蚁小二账号列表。如果发现新账号，自动在桌面创建素材库文件夹（C:/Users/wlb/Desktop/{账号名}的素材库），并初始化素材库结构。',
      scheduleType: 'recurring',
      rrule: 'FREQ=MINUTELY;INTERVAL=30',
      status: 'ACTIVE'
    }
  ];
  
  const configPath = join(DATA_DIR, 'automations-config.json');
  writeFileSync(configPath, JSON.stringify(automations, null, 2));
  log('WorkBuddy 自动化配置已生成', 'SUCCESS');
  log(`配置文件: ${configPath}`, 'INFO');
  
  return automations;
}

// 打印任务创建摘要
function printSummary(results) {
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║              🎉 定时任务创建完成！                            ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  📋 创建的任务：                                              ║
║                                                              ║
║  1. 新媒体心跳监控                                           ║
║     • 执行频率：每 2 小时                                     ║
║     • 功能：监控账号状态、发布队列、素材库                     ║
║     • Windows任务：MediaBrainZero_HeartbeatMonitor           ║
║                                                              ║
║  2. 账号扫描任务                                              ║
║     • 执行频率：每 30 分钟                                    ║
║     • 功能：扫描新账号，自动创建素材库文件夹                   ║
║     • Windows任务：MediaBrainZero_AccountScanner             ║
║                                                              ║
║  📁 素材库文件夹位置：                                       ║
║     C:/Users/wlb/Desktop/{账号名}的素材库                     ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
  `);
}

// 主函数
async function main() {
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║        🔧 Media Brain Zero - 自动化任务设置器                  ║
╚══════════════════════════════════════════════════════════════╝
  `);
  
  // 1. 创建 Windows 定时任务
  const taskResults = await createAllScheduledTasks();
  
  // 2. 生成 WorkBuddy 自动化配置
  const automations = generateWorkBuddyAutomations();
  
  // 3. 打印摘要
  printSummary({ tasks: taskResults, automations });
  
  // 4. 返回结果
  return {
    status: 'success',
    windowsTasks: taskResults,
    automations,
    nextSteps: [
      '打开 WorkBuddy',
      '在自动化设置中导入 automations-config.json',
      '或者直接告诉我"启动心跳监控"来手动测试'
    ]
  };
}

// 命令行参数处理
const args = process.argv.slice(2);
if (args.includes('--help') || args.includes('-h')) {
  console.log(`
Media Brain Zero - 自动化任务设置器

用法:
  node setup-automations.mjs [选项]

选项:
  --heartbeat    只创建心跳监控任务
  --scanner      只创建账号扫描任务
  --list         列出所有任务
  --help, -h     显示帮助信息
  `);
  process.exit(0);
} else if (args.includes('--list')) {
  // 列出所有任务
  exec('schtasks /Query /FO LIST | findstr MediaBrain', (err, stdout) => {
    if (stdout) {
      console.log('当前 Media Brain 定时任务:');
      console.log(stdout);
    } else {
      console.log('未找到 Media Brain 定时任务');
    }
  });
} else if (args.includes('--heartbeat')) {
  const script = createHeartbeatTaskScript();
  createScheduledTask('MediaBrainZero_HeartbeatMonitor', script, { unit: 'hours', interval: 2 });
} else if (args.includes('--scanner')) {
  const script = createScannerTaskScript();
  createScheduledTask('MediaBrainZero_AccountScanner', script, { unit: 'minutes', interval: 30 });
} else {
  main();
}

export { main, createScheduledTask, createAllScheduledTasks, createAccountFolder, createAllAccountFolders };
