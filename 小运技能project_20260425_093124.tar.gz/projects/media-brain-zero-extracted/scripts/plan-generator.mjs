#!/usr/bin/env node
/**
 * Media Brain Zero - 方案生成器
 * 功能：根据账号信息生成AI运营方案
 */

import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

// API配置
const CONFIG = {
  DEEPSEEK_API_KEY: process.env.DEEPSEEK_API_KEY || '',
  DEEPSEEK_API: 'https://api.deepseek.com/chat/completions'
};

// 日志
function log(message, type = 'INFO') {
  const prefix = { INFO: '📋', SUCCESS: '✅', WARN: '⚠️', ERROR: '❌', AI: '🧠' }[type] || '📝';
  console.log(`${prefix} [PlanGen] ${message}`);
}

// 调用DeepSeek API
async function callDeepSeek(prompt, temperature = 0.7) {
  if (!CONFIG.DEEPSEEK_API_KEY) {
    log('未配置DeepSeek API Key，使用默认方案', 'WARN');
    return null;
  }
  
  try {
    const response = await fetch(CONFIG.DEEPSEEK_API, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${CONFIG.DEEPSEEK_API_KEY}`
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [
          { role: 'system', content: '你是专业的新媒体运营顾问，输出JSON格式的运营方案。' },
          { role: 'user', content: prompt }
        ],
        temperature
      })
    });
    
    const data = await response.json();
    return data.choices?.[0]?.message?.content || null;
  } catch (error) {
    log(`AI调用失败: ${error.message}`, 'ERROR');
    return null;
  }
}

// 解析JSON响应
function parseJSONResponse(text) {
  try {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
  } catch (error) {
    log('JSON解析失败', 'ERROR');
  }
  return null;
}

// 判断账号阶段
function determineStage(fans, contentCount) {
  if (fans >= 10000 || contentCount >= 100) return 'mature';
  if (fans >= 1000 || contentCount >= 30) return 'growth';
  return 'cold_start';
}

// 获取阶段标签
function getStageLabel(stage) {
  return { cold_start: '冷启动期', growth: '成长期', mature: '成熟期' }[stage] || '未知';
}

// 获取平台特征
function getPlatformFeatures(platform) {
  const features = {
    '抖音': { contentType: '视频', duration: '15-60秒', key: '完播率、点赞' },
    '小红书': { contentType: '图文/视频', duration: '500字+图片', key: '收藏、评论' },
    '视频号': { contentType: '视频', duration: '30秒-3分钟', key: '分享、点赞' },
    '快手': { contentType: '视频', duration: '7-57秒', key: '老铁互动' },
    '知乎': { contentType: '文章/问答', duration: '800字+', key: '专业度、收藏' },
    'B站': { contentType: '视频', duration: '3-10分钟', key: '三连、弹幕' },
    '微博': { contentType: '短内容', duration: '140字', key: '转发、评论' },
    '今日头条': { contentType: '图文/视频', duration: '500字+', key: '阅读量' }
  };
  return features[platform] || { contentType: '图文/视频', duration: '不定', key: '互动' };
}

// 生成运营策略
function generateStrategy(stage, platform) {
  const strategies = {
    cold_start: {
      strategy: '建立专业形象，快速积累内容',
      priority: ['日更', '蹭热点', '干货分享'],
      contentFocus: '入门教程、工具推荐、效率技巧',
      avoid: ['带货', '硬广告', '争议话题']
    },
    growth: {
      strategy: '稳定输出，建立粉丝粘性',
      priority: ['隔日更', '系列内容', '互动活动'],
      contentFocus: '深度教程、案例分析、行业洞察',
      avoid: ['纯热点', '低质量蹭流量']
    },
    mature: {
      strategy: '品牌化运营，多元变现',
      priority: ['品牌活动', '粉丝福利', '跨界合作'],
      contentFocus: '品牌故事、VIP内容、独家资源',
      avoid: ['无规划发布', '频繁换风格']
    }
  };
  
  return strategies[stage] || strategies.cold_start;
}

// 生成每日发布计划
function generateDailyPlan(stage, platform) {
  const plans = {
    cold_start: { dailyPosts: 1, times: ['18:00-20:00'], reason: '新号需要稳定输出培养账号权重' },
    growth: { dailyPosts: 1, times: ['12:00-13:00', '18:00-20:00'], reason: '多时段测试，找到最佳时间' },
    mature: { dailyPosts: 2, times: ['08:00-09:00', '18:00-20:00'], reason: '成熟账号可多时段覆盖' }
  };
  
  return plans[stage] || plans.cold_start;
}

// 生成月度目标
function generateGoals(stage, fans) {
  const goals = {
    cold_start: { targetFans: Math.max(100, fans + 100), period: '30天', metric: '破百粉' },
    growth: { targetFans: Math.max(5000, fans + 3000), period: '90天', metric: '破千粉' },
    mature: { targetFans: Math.max(50000, fans + 20000), period: '180天', metric: '品牌影响力' }
  };
  
  return goals[stage] || goals.cold_start;
}

// AI生成方案（高级功能）
async function generateAIPlan(account) {
  const prompt = `为以下账号生成运营方案：

账号信息：
- 名称：${account.name}
- 平台：${account.platform}
- 粉丝数：${account.fans}
- 内容数：${account.contentCount}

要求：输出JSON格式，包含：
{
  "strategy": "核心策略",
  "contentType": "内容形式",
  "topics": ["话题1", "话题2", "话题3"],
  "publishTime": "最佳发布时间",
  "goals": {
    "shortTerm": "短期目标",
    "mediumTerm": "中期目标",
    "longTerm": "长期目标"
  },
  "contentIdeas": ["内容创意1", "内容创意2", "内容创意3"],
  "keyMetrics": ["关键指标1", "关键指标2"]
}`;

  const response = await callDeepSeek(prompt);
  if (response) {
    return parseJSONResponse(response);
  }
  return null;
}

// 生成运营方案（主函数）
export async function generateOperationPlan(account) {
  log(`正在为 "${account.name}" 生成运营方案...`, 'AI');
  
  // 1. 确定账号阶段
  const stage = account.stage || determineStage(account.fans, account.contentCount);
  const stageLabel = getStageLabel(stage);
  
  // 2. 获取平台特征
  const platformFeatures = getPlatformFeatures(account.platform);
  
  // 3. 生成策略
  const strategy = generateStrategy(stage, account.platform);
  
  // 4. 生成发布计划
  const dailyPlan = generateDailyPlan(stage, account.platform);
  
  // 5. 生成目标
  const goals = generateGoals(stage, account.fans);
  
  // 6. 尝试AI增强（如果配置了API）
  const aiPlan = await generateAIPlan(account);
  
  // 7. 构建完整方案
  const plan = {
    // 基本信息
    accountId: account.id,
    accountName: account.name,
    platform: account.platform,
    stage,
    stageLabel,
    generatedAt: new Date().toISOString(),
    
    // 策略
    strategy: aiPlan?.strategy || strategy.strategy,
    priorities: aiPlan?.topics || strategy.priority,
    contentFocus: strategy.contentFocus,
    avoid: strategy.avoid,
    
    // 内容
    contentType: aiPlan?.contentType || platformFeatures.contentType,
    contentLength: platformFeatures.duration,
    keyMetric: platformFeatures.key,
    
    // 发布
    dailyPosts: dailyPlan.dailyPosts,
    preferredTime: dailyPlan.times[0],
    publishTimes: dailyPlan.times,
    publishReason: dailyPlan.reason,
    
    // 目标
    goal: goals.metric,
    targetFans: goals.targetFans,
    period: goals.period,
    shortTerm: aiPlan?.goals?.shortTerm || `${goals.period}内粉丝翻倍`,
    mediumTerm: aiPlan?.goals?.mediumTerm || `建立稳定的内容输出体系`,
    longTerm: aiPlan?.goals?.longTerm || `成为领域头部账号`,
    
    // AI增强内容
    contentIdeas: aiPlan?.contentIdeas || [
      `${account.name}的入门指南`,
      `${account.platform}运营干货分享`,
      `行业案例分析`
    ],
    topics: aiPlan?.topics || strategy.priority,
    keyMetrics: aiPlan?.keyMetrics || [platformFeatures.key, '粉丝增长', '评论互动'],
    
    // 风险提示
    risks: [
      '平台算法变化可能导致流量波动',
      '热点话题时效性强，需快速响应',
      '内容同质化风险，需持续创新'
    ]
  };
  
  return plan;
}

// 生成完整方案文档
export async function generateFullReport(accounts, plans) {
  log('正在生成完整运营报告...', 'AI');
  
  const report = {
    title: 'Media Brain Zero 运营方案报告',
    generatedAt: new Date().toISOString(),
    summary: {
      totalAccounts: accounts.length,
      platforms: [...new Set(accounts.map(a => a.platform))],
      totalFans: accounts.reduce((sum, a) => sum + (a.fans || 0), 0),
      avgFans: Math.round(accounts.reduce((sum, a) => sum + (a.fans || 0), 0) / accounts.length)
    },
    accounts: accounts.map((acc, idx) => ({
      ...acc,
      plan: plans[idx]
    }))
  };
  
  return report;
}

// 默认导出
export default {
  generateOperationPlan,
  generateFullReport,
  determineStage,
  getStageLabel,
  getPlatformFeatures,
  generateStrategy,
  generateDailyPlan,
  generateGoals
};
