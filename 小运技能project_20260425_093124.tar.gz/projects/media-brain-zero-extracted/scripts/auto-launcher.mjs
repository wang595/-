#!/usr/bin/env node
/**
 * Media Brain Zero - 自动启动器
 * 功能：引导用户完成初始设置，自动检测蚁小二账号并启动运营
 */

import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT_DIR = join(__dirname, '..');
const DATA_DIR = join(ROOT_DIR, 'data');

// 导入模块
import { detectYiXiaoerLogin, openLoginPage } from './claw-bridge.mjs';
import { scanAccounts } from './account-scanner.mjs';
import { generateOperationPlan } from './plan-generator.mjs';
import { saveConfig, loadConfig } from './config-exporter.mjs';
import { createAllScheduledTasks, createAllAccountFolders } from './setup-automations.mjs';

const CONFIG_PATH = join(DATA_DIR, 'config.json');
const MEMORY_PATH = join(DATA_DIR, 'memory.json');

// 确保数据目录存在
import { mkdirSync } from 'fs';
mkdirSync(DATA_DIR, { recursive: true });

// 日志函数
function log(message, type = 'INFO') {
  const timestamp = new Date().toISOString();
  const prefix = {
    'INFO': 'ℹ️',
    'SUCCESS': '✅',
    'WARN': '⚠️',
    'ERROR': '❌',
    'AI': '🧠'
  }[type] || '📝';
  
  console.log(`${prefix} [${timestamp.split('T')[1].split('.')[0]}] ${message}`);
}

// 打印欢迎横幅
function printBanner() {
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║     🧠  Media Brain Zero - 零门槛自动化运营                    ║
║                                                              ║
║     "下载技能，登录蚁小二，剩下的交给我"                       ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
  `);
}

// 检查环境
async function checkEnvironment() {
  log('检查运行环境...', 'INFO');
  
  const checks = {
    nodejs: process.version.startsWith('v'),
    memory: existsSync(MEMORY_PATH),
    config: existsSync(CONFIG_PATH)
  };
  
  log(`Node.js: ${checks.nodejs ? '✅' : '❌'} ${process.version}`, 'INFO');
  
  return checks;
}

// 初始化配置
function initConfig() {
  const defaultConfig = {
    mode: 'zero',
    autoDetect: true,
    browser: 'auto',
    notifications: {
      daily: true,
      error: true,
     WeChat: false
    },
    publish: {
      maxDaily: 3,
      preferredTime: '18:00',
      hotspot: true
    },
    content: {
      style: 'professional',
      length: 'medium'
    },
    setup: {
      completed: false,
      setupDate: null,
      yixiaoerLinked: false
    }
  };
  
  if (!existsSync(CONFIG_PATH)) {
    writeFileSync(CONFIG_PATH, JSON.stringify(defaultConfig, null, 2));
    log('配置文件已创建', 'SUCCESS');
  }
  
  return loadConfig();
}

// 检测蚁小二登录状态
async function detectLogin() {
  log('正在检测蚁小二登录状态...', 'AI');
  
  try {
    const isLoggedIn = await detectYiXiaoerLogin();
    
    if (isLoggedIn) {
      log('检测到已登录蚁小二账号', 'SUCCESS');
      return true;
    } else {
      log('未检测到登录状态，需要引导登录', 'WARN');
      return false;
    }
  } catch (error) {
    log(`检测失败: ${error.message}`, 'ERROR');
    return false;
  }
}

// 引导登录
async function guideLogin() {
  log('正在打开蚁小二登录页面...', 'AI');
  
  try {
    await openLoginPage();
    log('浏览器已打开，请在浏览器中完成登录', 'SUCCESS');
    log('登录完成后，请回到此处告诉我"登录好了"', 'INFO');
    return true;
  } catch (error) {
    log(`无法打开浏览器: ${error.message}`, 'ERROR');
    log('请手动打开 https://www.yixiaoer.cn 并登录', 'WARN');
    return false;
  }
}

// 等待用户登录确认
async function waitForLoginConfirmation() {
  return new Promise((resolve) => {
    const checkInterval = setInterval(async () => {
      const isLoggedIn = await detectYiXiaoerLogin();
      if (isLoggedIn) {
        clearInterval(checkInterval);
        resolve(true);
      }
    }, 5000); // 每5秒检测一次
    
    // 设置超时（5分钟后停止检测）
    setTimeout(() => {
      clearInterval(checkInterval);
      resolve(false);
    }, 300000);
  });
}

// 扫描账号
async function scanYiXiaoerAccounts() {
  log('正在扫描蚁小二账号...', 'AI');
  
  try {
    const accounts = await scanAccounts();
    log(`扫描到 ${accounts.length} 个已绑定账号`, 'SUCCESS');
    return accounts;
  } catch (error) {
    log(`扫描失败: ${error.message}`, 'ERROR');
    return [];
  }
}

// 分析账号
async function analyzeAccounts(accounts) {
  log('正在分析账号数据...', 'AI');
  
  const analysis = accounts.map(acc => {
    // 判断账号阶段
    let stage = 'cold_start';
    if (acc.fans >= 1000) stage = 'growth';
    if (acc.fans >= 10000) stage = 'mature';
    
    // 判断平台
    const platform = acc.platform || '未知';
    
    return {
      id: acc.id,
      name: acc.name,
      platform,
      fans: acc.fans || 0,
      stage,
      stageLabel: {
        cold_start: '冷启动期',
        growth: '成长期',
        mature: '成熟期'
      }[stage],
      contentCount: acc.contentCount || 0,
      status: acc.status || 'active'
    };
  });
  
  return analysis;
}

// 生成并展示方案
async function generateAndShowPlans(accounts) {
  log('正在为每个账号生成运营方案...', 'AI');
  
  const plans = [];
  
  for (const account of accounts) {
    log(`生成 ${account.name} 的方案...`, 'INFO');
    
    try {
      const plan = await generateOperationPlan(account);
      plans.push({
        account,
        plan
      });
      
      // 打印方案摘要
      console.log(`
┌─────────────────────────────────────────────────────────────────┐
│  📋 ${account.name} (${account.platform}) - 运营方案              │
├─────────────────────────────────────────────────────────────────┤
│  阶段：${account.stageLabel}                                              │
│  策略：${plan.strategy}                                       │
│  内容：${plan.contentType}                                              │
│  目标：${plan.goal}                                               │
│  频率：每日 ${plan.dailyPosts} 条，${plan.preferredTime} 发布              │
└─────────────────────────────────────────────────────────────────┘
      `);
    } catch (error) {
      log(`生成 ${account.name} 方案失败: ${error.message}`, 'ERROR');
    }
  }
  
  return plans;
}

// 保存完整配置
async function saveFullConfig(accounts, plans) {
  const config = loadConfig();
  
  config.setup.completed = true;
  config.setup.setupDate = new Date().toISOString();
  config.setup.yixiaoerLinked = true;
  config.accounts = accounts.map(acc => ({
    id: acc.id,
    name: acc.name,
    platform: acc.platform,
    stage: acc.stage,
    linked: true
  }));
  config.plans = plans.map(p => ({
    accountId: p.account.id,
    strategy: p.plan.strategy,
    contentType: p.plan.contentType,
    goal: p.plan.goal,
    dailyPosts: p.plan.dailyPosts,
    preferredTime: p.plan.preferredTime,
    createdAt: new Date().toISOString()
  }));
  
  saveConfig(config);
  log('配置已保存', 'SUCCESS');
}

// 启动自动运营
async function startAutoOperation(config) {
  log('🚀 开始自动运营...', 'AI');
  
  const accountCount = config.accounts?.length || 0;
  
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║                    🎉 设置完成！开始运营                         ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  📊 管理账号数：${accountCount} 个                                         ║
║  ⏰ 运营模式：24小时无人值守                                    ║
║  📅 报告时间：每日 ${config.publish?.preferredTime || '18:00'}                                     ║
║                                                              ║
║  ✅ 已创建定时任务：                                            ║
║  • 心跳监控（每2小时）- 监控账号状态                            ║
║  • 账号扫描（每30分钟）- 发现新账号自动建文件夹                   ║
║                                                              ║
║  ✅ 已创建素材库文件夹：                                        ║
║  • 桌面/{账号名}的素材库                                        ║
║                                                              ║
║  系统将自动：                                                  ║
║  • 追踪热点话题                                               ║
║  • 生成内容文案                                               ║
║  • 自动发布到各平台                                           ║
║  • 监控发布状态                                               ║
║  • 每日推送运营报告                                           ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
  `);
  
  log('首次内容生成将在下次定时任务中执行', 'INFO');
  log('您现在可以：', 'INFO');
  log('  • 输入"今日报告"查看当前状态', 'INFO');
  log('  • 输入"调整方案"修改运营策略', 'INFO');
  log('  • 输入"暂停运营"临时停止', 'INFO');
}

// 主流程
async function main() {
  printBanner();
  
  // 1. 检查环境
  await checkEnvironment();
  
  // 2. 初始化配置
  const config = initConfig();
  
  // 3. 检测登录状态
  const isLoggedIn = await detectLogin();
  
  if (!isLoggedIn) {
    // 引导登录
    await guideLogin();
    
    // 等待用户确认登录
    log('请在浏览器中完成登录后，告诉我"登录好了"', 'AI');
    
    // 这里应该等待用户输入确认，但由于是脚本模式
    // 我们改为直接返回提示信息
    console.log(`
┌─────────────────────────────────────────────────────────────────┐
│  ⏳ 等待登录确认                                                  │
│                                                                  │
│  请在打开的浏览器中：                                             │
│  1. 使用手机号+验证码登录蚁小二                                    │
│  2. 登录成功后告诉我"登录好了"                                     │
│                                                                  │
│  或者直接运行以下命令继续：                                        │
│  node scripts/auto-launcher.mjs --continue                       │
└─────────────────────────────────────────────────────────────────┘
    `);
    
    return {
      status: 'awaiting_login',
      message: '请完成蚁小二登录后再次运行'
    };
  }
  
  // 4. 扫描账号
  const rawAccounts = await scanYiXiaoerAccounts();
  
  if (rawAccounts.length === 0) {
    log('未扫描到任何账号，请在蚁小二中添加账号后重试', 'ERROR');
    return {
      status: 'no_accounts',
      message: '请先在蚁小二中添加要运营的平台账号'
    };
  }
  
  // 5. 分析账号
  const accounts = await analyzeAccounts(rawAccounts);
  
  // 5.1 为每个账号创建桌面素材库文件夹
  log('正在为每个账号创建桌面素材库文件夹...', 'INFO');
  const folderResults = await createAllAccountFolders(accounts);

  // 6. 生成方案
  const plans = await generateAndShowPlans(accounts);
  
  // 7. 保存配置
  await saveFullConfig(accounts, plans);
  
  // 8. 创建定时任务（心跳监控 + 账号扫描）
  log('正在创建定时任务...', 'INFO');
  try {
    const taskResults = await createAllScheduledTasks();
    log('定时任务创建完成', 'SUCCESS');
  } catch (error) {
    log(`创建定时任务失败: ${error.message}`, 'WARN');
    log('定时任务将在下次启动时自动创建', 'INFO');
  }
  
  // 8. 启动运营
  await startAutoOperation(config);
  
  return {
    status: 'success',
    accounts,
    plans
  };
}

// 命令行参数处理
const args = process.argv.slice(2);
if (args.includes('--continue') || args.includes('-c')) {
  log('继续上次流程...', 'INFO');
  main();
} else {
  main();
}

export { main };
