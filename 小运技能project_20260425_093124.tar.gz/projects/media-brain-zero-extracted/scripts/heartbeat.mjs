#!/usr/bin/env node
/**
 * Media Brain Zero - 心跳监控系统
 * 
 * 功能：
 * 1. 账号状态扫描 - 检测所有绑定账号的健康状态
 * 2. 发布队列监控 - 检查待发布内容队列
 * 3. 素材库监控 - 检查新素材和素材库状态
 * 4. 用户行为检测 - 自动整理素材
 * 5. 日报生成 - 在指定时间生成日报
 * 6. 执行日志记录 - 记录所有监控结果
 * 
 * 作者：洞察 (Dongcha) - 效果追踪代理
 * 日期：2026-04-10
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import os from 'os';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT_DIR = join(__dirname, '..');
const DATA_DIR = join(ROOT_DIR, 'data');
const LOG_PATH = join(DATA_DIR, 'heartbeat-log.json');

// 报告时间配置
const DAILY_REPORT_HOUR = 20; // 20:00 发送日报

// 日志函数
function log(message, type = 'INFO') {
  const icons = {
    HEARTBEAT: '💓',
    SCAN: '🔍',
    QUEUE: '📋',
    MATERIAL: '📦',
    BEHAVIOR: '🧠',
    REPORT: '📊',
    SUCCESS: '✅',
    WARN: '⚠️',
    ERROR: '❌',
    INFO: 'ℹ️'
  };
  const timestamp = new Date().toLocaleTimeString('zh-CN');
  console.log(`${icons[type] || '📝'} [${timestamp}] ${message}`);
}

/**
 * 确保目录存在
 */
function ensureDir(dir) {
  if (!existsSync(dir)) {
    mkdirSync(dir, { recursive: true });
  }
}

/**
 * 读取配置文件
 */
function loadConfig() {
  const configPath = join(DATA_DIR, 'config.json');
  if (!existsSync(configPath)) {
    return null;
  }
  try {
    return JSON.parse(readFileSync(configPath, 'utf8'));
  } catch (e) {
    return null;
  }
}

/**
 * 读取心跳日志
 */
function loadHeartbeatLog() {
  if (!existsSync(LOG_PATH)) {
    return [];
  }
  try {
    return JSON.parse(readFileSync(LOG_PATH, 'utf8'));
  } catch (e) {
    return [];
  }
}

/**
 * 保存心跳日志
 */
function saveHeartbeatLog(entry) {
  ensureDir(DATA_DIR);
  const logs = loadHeartbeatLog();
  logs.push(entry);
  // 只保留最近100条记录
  if (logs.length > 100) {
    logs.shift();
  }
  writeFileSync(LOG_PATH, JSON.stringify(logs, null, 2), 'utf8');
}

/**
 * 1. 账号状态扫描
 */
async function scanAccountStatus() {
  log('开始扫描账号状态...', 'SCAN');
  
  // 尝试从进化系统读取账号档案
  const memoryDir = join(ROOT_DIR, 'evolution', 'memory');
  const accounts = [];
  
  if (existsSync(memoryDir)) {
    const accountDirs = readdirSync(memoryDir).filter(f => {
      return existsSync(join(memoryDir, f, 'profile.json'));
    });
    
    for (const accountId of accountDirs) {
      try {
        const profilePath = join(memoryDir, accountId, 'profile.json');
        const profile = JSON.parse(readFileSync(profilePath, 'utf8'));
        accounts.push({
          id: accountId,
          name: profile.name || '未命名',
          platform: profile.platform || '未知',
          status: profile.status || 'active',
          fans: profile.fans || 0
        });
      } catch (e) {
        // 忽略读取错误
      }
    }
  }
  
  const activeAccounts = accounts.filter(a => a.status === 'active');
  
  return {
    status: accounts.length > 0 ? 'success' : 'warning',
    message: accounts.length > 0 
      ? `发现 ${accounts.length} 个账号，${activeAccounts.length} 个活跃` 
      : '未发现绑定的账号',
    accountsFound: accounts.length,
    accountsActive: activeAccounts.length,
    accountsInactive: accounts.length - activeAccounts.length,
    accounts: accounts
  };
}

/**
 * 2. 检查发布队列
 */
async function checkPublishQueue() {
  log('检查发布队列...', 'QUEUE');
  
  const desktopRoot = join('C:', 'Users', os.userInfo().username, 'Desktop', '新媒体素材库');
  
  if (!existsSync(desktopRoot)) {
    return {
      status: 'info',
      message: '素材库尚未初始化',
      pendingCount: 0,
      publishingCount: 0,
      publishedCount: 0,
      queueItems: []
    };
  }
  
  // 扫描所有账号的素材库
  const accounts = [];
  const entries = readdirSync(desktopRoot);
  
  for (const entry of entries) {
    const entryPath = join(desktopRoot, entry);
    if (entry.includes('专属素材库')) {
      const accountName = entry.replace('的专属素材库', '');
      const queuePath = join(entryPath, '📥待发布内容', '_队列.json');
      
      if (existsSync(queuePath)) {
        try {
          const queueData = JSON.parse(readFileSync(queuePath, 'utf8'));
          accounts.push({
            name: accountName,
            pendingCount: queueData.count || 0,
            items: queueData.items || []
          });
        } catch (e) {
          // 忽略读取错误
        }
      }
    }
  }
  
  const totalPending = accounts.reduce((sum, a) => sum + a.pendingCount, 0);
  const queueItems = accounts.flatMap(a => 
    a.items.slice(0, 5).map(i => `${i.title} (${a.name})`)
  );
  
  return {
    status: totalPending > 0 ? 'info' : 'success',
    message: totalPending > 0 ? `有 ${totalPending} 条内容待发布` : '发布队列为空',
    pendingCount: totalPending,
    publishingCount: 0,
    publishedCount: accounts.reduce((sum, a) => sum + (a.publishedCount || 0), 0),
    queueItems: queueItems
  };
}

/**
 * 3. 检查素材库
 */
async function checkMaterialLibrary() {
  log('检查素材库状态...', 'MATERIAL');
  
  const desktopRoot = join('C:', 'Users', os.userInfo().username, 'Desktop', '新媒体素材库');
  
  if (!existsSync(desktopRoot)) {
    return {
      status: 'warning',
      message: '素材库尚未初始化',
      totalMaterials: 0,
      pendingMaterials: 0,
      publishedMaterials: 0,
      enterpriseMaterials: 0,
      categories: {}
    };
  }
  
  // 统计所有账号的素材
  let totalStats = {
    totalMaterials: 0,
    pendingMaterials: 0,
    publishedMaterials: 0,
    enterpriseMaterials: 0,
    categories: {
      '厂区环境': 0,
      '产品展示': 0,
      '团队风采': 0,
      '其他': 0
    }
  };
  
  const entries = readdirSync(desktopRoot);
  
  for (const entry of entries) {
    const libPath = join(desktopRoot, entry);
    if (entry.includes('专属素材库')) {
      const indexPath = join(libPath, '📋素材索引.json');
      
      if (existsSync(indexPath)) {
        try {
          const index = JSON.parse(readFileSync(indexPath, 'utf8'));
          totalStats.totalMaterials += index.stats?.totalCount || 0;
          totalStats.pendingMaterials += index.stats?.pendingCount || 0;
          totalStats.publishedMaterials += index.stats?.publishedCount || 0;
        } catch (e) {
          // 忽略读取错误
        }
      }
      
      // 统计企业素材
      const enterprisePath = join(libPath, '🏭企业素材');
      if (existsSync(enterprisePath)) {
        for (const cat of Object.keys(totalStats.categories)) {
          const catPath = join(enterprisePath, cat);
          if (existsSync(catPath)) {
            try {
              const files = readdirSync(catPath);
              const mediaFiles = files.filter(f => {
                const ext = f.toLowerCase().slice(f.lastIndexOf('.'));
                return ['.jpg', '.jpeg', '.png', '.gif', '.mp4', '.mov', '.webp'].includes(ext);
              });
              totalStats.categories[cat] += mediaFiles.length;
              totalStats.enterpriseMaterials += mediaFiles.length;
            } catch (e) {
              // 忽略读取错误
            }
          }
        }
      }
    }
  }
  
  return {
    status: totalStats.totalMaterials > 0 ? 'success' : 'info',
    message: totalStats.totalMaterials > 0 
      ? `素材库共有 ${totalStats.totalMaterials} 个素材` 
      : '素材库为空',
    ...totalStats
  };
}

/**
 * 4. 用户行为检测（自动整理素材）
 */
async function detectUserBehavior() {
  log('执行用户行为检测...', 'BEHAVIOR');
  
  // 扫描桌面和下载文件夹中的新素材
  const scanPaths = [
    join('C:', 'Users', os.userInfo().username, 'Desktop'),
    join('C:', 'Users', os.userInfo().username, 'Downloads')
  ];
  
  const newMaterials = [];
  const mediaExts = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.mp4', '.mov', '.avi'];
  
  for (const scanPath of scanPaths) {
    if (!existsSync(scanPath)) continue;
    
    try {
      const files = readdirSync(scanPath);
      for (const file of files) {
        const ext = file.toLowerCase().slice(file.lastIndexOf('.'));
        if (mediaExts.includes(ext)) {
          newMaterials.push({
            name: file,
            path: join(scanPath, file),
            type: 'media'
          });
        }
      }
    } catch (e) {
      // 忽略读取错误
    }
  }
  
  return {
    status: newMaterials.length > 0 ? 'info' : 'success',
    message: newMaterials.length > 0 
      ? `检测到 ${newMaterials.length} 个新素材需要整理` 
      : '未检测到新素材需要整理',
    filesOrganized: 0,
    newMaterialsFound: newMaterials.length
  };
}

/**
 * 5. 生成日报
 */
async function generateDailyReport(accountStatus, queueStatus, materialStatus) {
  const now = new Date();
  const currentHour = now.getHours();
  
  // 检查是否是报告时间（20:00）
  if (currentHour !== DAILY_REPORT_HOUR) {
    return {
      status: 'skipped',
      reason: `当前时间 ${String(currentHour).padStart(2, '0')}:00 未到报告时间 ${DAILY_REPORT_HOUR}:00`
    };
  }
  
  log('生成日报...', 'REPORT');
  
  // 生成报告内容
  const reportDate = now.toLocaleDateString('zh-CN');
  const reportContent = `# 📊 新媒体运营日报 - ${reportDate}

## 📈 今日概览

| 指标 | 数值 | 状态 |
|------|------|------|
| 活跃账号 | ${accountStatus.accountsActive}/${accountStatus.accountsFound} | ${accountStatus.accountsActive > 0 ? '✅' : '⚠️'} |
| 待发布内容 | ${queueStatus.pendingCount} 条 | ${queueStatus.pendingCount > 0 ? '📋' : '✅'} |
| 素材库总量 | ${materialStatus.totalMaterials} 个 | ${materialStatus.totalMaterials > 0 ? '✅' : 'ℹ️'} |
| 企业素材 | ${materialStatus.enterpriseMaterials} 个 | ${materialStatus.enterpriseMaterials > 0 ? '✅' : '⚠️'} |

## 🔍 账号状态

${accountStatus.accounts.map(a => `- **${a.name}** (${a.platform}) - 粉丝: ${a.fans} - 状态: ${a.status === 'active' ? '✅ 活跃' : '⚠️ 非活跃'}`).join('\n') || '暂无账号数据'}

## 📋 待发布队列

${queueStatus.queueItems.length > 0 
  ? queueStatus.queueItems.map((item, i) => `${i + 1}. ${item}`).join('\n')
  : '队列为空'}

## 📦 素材库统计

- 待发布: ${materialStatus.pendingMaterials} 个
- 已发布: ${materialStatus.publishedMaterials} 个
- 企业素材: ${materialStatus.enterpriseMaterials} 个

### 企业素材分类
${Object.entries(materialStatus.categories || {}).map(([cat, count]) => `- ${cat}: ${count} 个`).join('\n')}

## ⚠️ 注意事项

${accountStatus.accountsActive === 0 ? '- 暂无活跃账号，请检查账号绑定状态\n' : ''}${materialStatus.enterpriseMaterials === 0 ? '- 企业素材库为空，建议上传真实素材以提升内容质量\n' : ''}${queueStatus.pendingCount === 0 ? '- 待发布队列为空，系统将自动生成新内容\n' : ''}

---
*报告生成时间: ${now.toLocaleString('zh-CN')}*
*Media Brain Zero - 效果追踪代理*
`;
  
  // 保存日报
  const reportDir = join(DATA_DIR, 'reports');
  ensureDir(reportDir);
  const reportPath = join(reportDir, `daily-report-${now.toISOString().split('T')[0]}.md`);
  writeFileSync(reportPath, reportContent, 'utf8');
  
  log(`日报已保存: ${reportPath}`, 'SUCCESS');
  
  return {
    status: 'success',
    path: reportPath,
    content: reportContent
  };
}

/**
 * 生成告警信息
 */
function generateAlerts(accountStatus, queueStatus, materialStatus, behaviorStatus) {
  const alerts = [];
  
  // 账号告警
  if (accountStatus.accountsActive === 0 && accountStatus.accountsFound === 0) {
    alerts.push({
      level: 'warning',
      category: '账号连接',
      message: '未发现绑定的账号，系统无法执行发布操作',
      action: '请绑定至少一个新媒体账号'
    });
  } else if (accountStatus.accountsActive === 0) {
    alerts.push({
      level: 'warning',
      category: '账号状态',
      message: '所有账号均处于非活跃状态',
      action: '请检查账号登录状态或重新授权'
    });
  }
  
  // 素材告警
  if (materialStatus.enterpriseMaterials === 0) {
    alerts.push({
      level: 'info',
      category: '素材库',
      message: '企业素材库为空，AI生成内容将缺乏真实素材支撑',
      action: '将企业真实素材放入「🏭企业素材」对应分类文件夹'
    });
  }
  
  // 队列告警
  if (queueStatus.pendingCount > 10) {
    alerts.push({
      level: 'info',
      category: '发布队列',
      message: `待发布内容积压 ${queueStatus.pendingCount} 条，建议增加发布频率`,
      action: '检查发布配置或手动触发发布'
    });
  }
  
  return alerts;
}

/**
 * 主函数 - 执行心跳监控
 */
async function runHeartbeat() {
  log('═══════════════════════════════════════════', 'HEARTBEAT');
  log('     💓 Media Brain Zero 心跳监控启动', 'HEARTBEAT');
  log('═══════════════════════════════════════════', 'HEARTBEAT');
  
  const startTime = Date.now();
  const timestamp = new Date().toISOString();
  
  // 确保数据目录存在
  ensureDir(DATA_DIR);
  
  // 执行各项检查
  const accountStatus = await scanAccountStatus();
  const queueStatus = await checkPublishQueue();
  const materialStatus = await checkMaterialLibrary();
  const behaviorStatus = await detectUserBehavior();
  
  // 生成日报（如果是报告时间）
  const reportStatus = await generateDailyReport(accountStatus, queueStatus, materialStatus);
  
  // 生成告警
  const alerts = generateAlerts(accountStatus, queueStatus, materialStatus, behaviorStatus);
  
  // 计算执行时间
  const duration = Date.now() - startTime;
  
  // 统计问题数量
  const warnings = alerts.filter(a => a.level === 'warning').length;
  const errors = alerts.filter(a => a.level === 'error').length;
  
  // 构建监控结果
  const heartbeatResult = {
    timestamp,
    type: 'heartbeat',
    status: errors > 0 ? 'error' : warnings > 0 ? 'warning' : 'success',
    checks: {
      accountScan: {
        status: accountStatus.status,
        message: accountStatus.message,
        accountsFound: accountStatus.accountsFound,
        accountsActive: accountStatus.accountsActive
      },
      publishQueue: {
        status: queueStatus.status,
        pendingCount: queueStatus.pendingCount,
        publishingCount: queueStatus.publishingCount,
        publishedCount: queueStatus.publishedCount,
        queueItems: queueStatus.queueItems
      },
      materialLib: {
        status: materialStatus.status,
        totalMaterials: materialStatus.totalMaterials,
        pendingMaterials: materialStatus.pendingMaterials,
        publishedMaterials: materialStatus.publishedMaterials,
        enterpriseMaterials: materialStatus.enterpriseMaterials,
        categories: materialStatus.categories
      },
      behaviorDetection: {
        status: behaviorStatus.status,
        message: behaviorStatus.message,
        filesOrganized: behaviorStatus.filesOrganized,
        newMaterialsFound: behaviorStatus.newMaterialsFound
      },
      dailyReport: reportStatus
    },
    alerts,
    summary: {
      totalIssues: alerts.length,
      warnings,
      errors,
      duration: `${duration}ms`,
      nextCheck: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString() // 2小时后
    }
  };
  
  // 保存日志
  saveHeartbeatLog(heartbeatResult);
  
  // 输出监控报告
  console.log('\n');
  log('═══════════════════════════════════════════', 'HEARTBEAT');
  log('           📊 心跳监控报告', 'HEARTBEAT');
  log('═══════════════════════════════════════════', 'HEARTBEAT');
  
  console.log(`
┌─────────────────────────────────────────────────────────────────┐
│  检查项              状态      详情                              │
├─────────────────────────────────────────────────────────────────┤
│  🔍 账号扫描         ${accountStatus.status === 'success' ? '✅' : '⚠️'}       ${accountStatus.message.substring(0, 40).padEnd(40)}│
│  📋 发布队列         ${queueStatus.status === 'success' ? '✅' : queueStatus.pendingCount > 0 ? '📋' : 'ℹ️'}       ${queueStatus.message.substring(0, 40).padEnd(40)}│
│  📦 素材库           ${materialStatus.status === 'success' ? '✅' : 'ℹ️'}       ${materialStatus.message.substring(0, 40).padEnd(40)}│
│  🧠 行为检测         ${behaviorStatus.status === 'success' ? '✅' : 'ℹ️'}       ${behaviorStatus.message.substring(0, 40).padEnd(40)}│
│  📊 日报生成         ${reportStatus.status === 'success' ? '✅' : reportStatus.status === 'skipped' ? '⏭️' : '❌'}       ${(reportStatus.reason || reportStatus.message || '已生成').substring(0, 40).padEnd(40)}│
└─────────────────────────────────────────────────────────────────┘
`);
  
  // 输出告警
  if (alerts.length > 0) {
    log('⚠️ 发现以下需要注意的事项:', 'WARN');
    alerts.forEach((alert, i) => {
      const icon = alert.level === 'error' ? '❌' : alert.level === 'warning' ? '⚠️' : 'ℹ️';
      console.log(`  ${icon} [${alert.category}] ${alert.message}`);
      console.log(`     💡 建议: ${alert.action}`);
    });
  } else {
    log('✅ 所有检查项正常，系统运行良好', 'SUCCESS');
  }
  
  console.log(`
┌─────────────────────────────────────────────────────────────────┐
│  执行时间: ${duration}ms${' '.repeat(45 - String(duration).length)}│
│  问题数量: ${warnings} 个警告, ${errors} 个错误${' '.repeat(33 - String(warnings).length - String(errors).length)}│
│  下次检查: ${new Date(heartbeatResult.summary.nextCheck).toLocaleString('zh-CN')}${' '.repeat(20)}│
└─────────────────────────────────────────────────────────────────┘
`);
  
  log('💓 心跳监控完成', 'HEARTBEAT');
  
  return heartbeatResult;
}

// 如果直接运行此脚本
const isMainModule = import.meta.url === `file://${process.argv[1]}` || 
                     import.meta.url === `file:///${process.argv[1].replace(/\\/g, '/')}` ||
                     process.argv[1].includes('heartbeat.mjs');

if (isMainModule) {
  runHeartbeat().catch(error => {
    console.error('心跳监控执行失败:', error);
    process.exit(1);
  });
}

export { runHeartbeat };
export default runHeartbeat;
