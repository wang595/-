#!/usr/bin/env node
/**
 * Media Brain Zero - 龙虾(CLAW)浏览器自动化桥接
 * 功能：检测蚁小二登录状态、自动打开登录页面
 * 
 * 支持的浏览器自动化方式：
 * 1. OpenClaw (龙虾) - 原生支持
 * 2. Browser Use CLI - 备选方案
 * 3. Playwright - 开发环境
 */

import { exec, spawn } from 'child_process';
import { promisify } from 'util';
import { existsSync, writeFileSync, readFileSync } from 'fs';
import { join } from 'path';

const execAsync = promisify(exec);

// 配置
const YIXIAOER_URL = 'https://www.yixiaoer.cn';
const YIXIAOER_API = 'https://www.yixiaoer.cn/api';
const CHECK_INTERVAL = 3000; // 3秒

// 日志
function log(message, type = 'INFO') {
  const prefix = { INFO: '🌐', SUCCESS: '✅', WARN: '⚠️', ERROR: '❌' }[type] || '📝';
  console.log(`${prefix} [CLAW] ${message}`);
}

// 检测claw是否存在
async function isClawAvailable() {
  try {
    const { stdout } = await execAsync('which claw || where claw 2>nul || echo "not found"');
    return !stdout.includes('not found');
  } catch {
    return false;
  }
}

// 检测browser-use是否存在
async function isBrowserUseAvailable() {
  try {
    const { stdout } = await execAsync('where browser-use 2>nul || echo "not found"');
    return !stdout.includes('not found');
  } catch {
    return false;
  }
}

// 使用OpenClaw(龙虾)打开页面
async function openWithClaw(url) {
  log('使用OpenClaw(龙虾)打开页面...');
  
  try {
    // claw open <url>
    await execAsync(`claw open "${url}"`);
    log('页面已在龙虾中打开', 'SUCCESS');
    return true;
  } catch (error) {
    log(`龙虾打开失败: ${error.message}`, 'WARN');
    return false;
  }
}

// 使用browser-use打开页面
async function openWithBrowserUse(url) {
  log('使用browser-use打开页面...');
  
  try {
    // browser-use CLI
    await execAsync(`browser-use --url "${url}"`);
    log('页面已在浏览器中打开', 'SUCCESS');
    return true;
  } catch (error) {
    log(`browser-use打开失败: ${error.message}`, 'WARN');
    return false;
  }
}

// 使用系统默认浏览器打开
async function openWithSystemBrowser(url) {
  log('使用系统默认浏览器打开...');
  
  const platform = process.platform;
  
  try {
    if (platform === 'win32') {
      await execAsync(`start "" "${url}"`);
    } else if (platform === 'darwin') {
      await execAsync(`open "${url}"`);
    } else {
      await execAsync(`xdg-open "${url}"`);
    }
    log('页面已在浏览器中打开', 'SUCCESS');
    return true;
  } catch (error) {
    log(`系统浏览器打开失败: ${error.message}`, 'ERROR');
    return false;
  }
}

// 通用打开页面函数
async function openPage(url) {
  // 优先使用龙虾
  if (await isClawAvailable()) {
    return await openWithClaw(url);
  }
  
  // 其次使用browser-use
  if (await isBrowserUseAvailable()) {
    return await openWithBrowserUse(url);
  }
  
  // 最后使用系统浏览器
  return await openWithSystemBrowser(url);
}

// 打开蚁小二登录页面
export async function openLoginPage() {
  log('正在打开蚁小二登录页面...');
  return await openPage(`${YIXIAOER_URL}/#/login`);
}

// 打开蚁小二控制台
export async function openConsole() {
  log('正在打开蚁小二控制台...');
  return await openPage(`${YIXIAOER_URL}/#/console`);
}

// 打开账号管理页面
export async function openAccountManagement() {
  log('正在打开账号管理页面...');
  return await openPage(`${YIXIAOER_URL}/#/account/list`);
}

// 检测蚁小二登录状态（通过API）
export async function checkLoginStatusByAPI() {
  try {
    // 尝试调用获取账号列表接口（需要登录）
    const response = await fetch(`${YIXIAOER_API}/v2/platform/accounts`, {
      method: 'GET',
      headers: {
        'Authorization': process.env.YIXIAOER_API_KEY || ''
      }
    });
    
    const data = await response.json();
    
    // statusCode 0 表示成功（有权限）
    if (data.statusCode === 0 || data.code === 0) {
      return { loggedIn: true, accounts: data.data || [] };
    }
    
    // 未登录或权限不足
    return { loggedIn: false, error: data.message || '未登录' };
  } catch (error) {
    // API调用失败，可能是网络问题或未配置API Key
    log(`API检测失败: ${error.message}`, 'WARN');
    return { loggedIn: null, error: error.message };
  }
}

// 检测登录状态（通过Cookie/LocalStorage）
export async function checkLoginStatusByBrowser() {
  // 这个功能需要浏览器扩展支持
  // 目前通过API方式更可靠
  return await checkLoginStatusByAPI();
}

// 综合检测登录状态
export async function detectYiXiaoerLogin() {
  log('检测蚁小二登录状态...');
  
  // 方式1：API检测（主要方式）
  const apiResult = await checkLoginStatusByAPI();
  
  if (apiResult.loggedIn === true) {
    log('API检测：已登录', 'SUCCESS');
    return true;
  }
  
  if (apiResult.loggedIn === false) {
    log(`API检测：未登录 (${apiResult.error})`, 'WARN');
    return false;
  }
  
  // 方式2：API Key检测（备用方式）
  const apiKey = process.env.YIXIAOER_API_KEY;
  if (apiKey) {
    log('检测到API Key配置，尝试验证...', 'INFO');
    // API Key存在且可用，说明已授权
    return true;
  }
  
  // 无法确定，提示用户
  log('无法确定登录状态，请手动确认', 'WARN');
  return false;
}

// 执行浏览器自动化任务（高级功能）
export async function executeBrowserTask(task) {
  log(`执行浏览器任务: ${task.description || '自定义任务'}`);
  
  // 生成任务脚本
  const scriptPath = join(__dirname, '../data/current_task.json');
  writeFileSync(scriptPath, JSON.stringify({
    task,
    createdAt: new Date().toISOString(),
    status: 'pending'
  }, null, 2));
  
  try {
    // 尝试使用claw执行任务
    if (await isClawAvailable()) {
      // claw run-task <task-file>
      const { stdout } = await execAsync(`claw run-task "${scriptPath}"`);
      log('任务执行完成', 'SUCCESS');
      return { success: true, result: stdout };
    }
    
    // 备选：browser-use
    if (await isBrowserUseAvailable()) {
      const { stdout } = await execAsync(`browser-use --task "${scriptPath}"`);
      log('任务执行完成', 'SUCCESS');
      return { success: true, result: stdout };
    }
    
    throw new Error('无可用的浏览器自动化工具');
  } catch (error) {
    log(`任务执行失败: ${error.message}`, 'ERROR');
    return { success: false, error: error.message };
  }
}

// 等待页面加载完成
export async function waitForPageLoad(selector, timeout = 30000) {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();
    
    const check = async () => {
      try {
        // 这里需要集成到实际的浏览器自动化框架中
        // 暂时返回超时
        if (Date.now() - startTime > timeout) {
          reject(new Error('页面加载超时'));
        } else {
          setTimeout(check, 1000);
        }
      } catch (error) {
        reject(error);
      }
    };
    
    check();
  });
}

// 截图功能
export async function takeScreenshot(name = 'screenshot') {
  const screenshotPath = join(__dirname, `../data/${name}_${Date.now()}.png`);
  
  try {
    if (await isClawAvailable()) {
      await execAsync(`claw screenshot "${screenshotPath}"`);
      log(`截图已保存: ${screenshotPath}`, 'SUCCESS');
      return screenshotPath;
    }
    
    throw new Error('无可用的截图工具');
  } catch (error) {
    log(`截图失败: ${error.message}`, 'ERROR');
    return null;
  }
}

// 获取浏览器自动化工具列表
export function getAvailableTools() {
  return {
    claw: isClawAvailable(),
    browserUse: isBrowserUseAvailable(),
    playwright: existsSync(join(__dirname, '../node_modules/playwright'))
  };
}

// 导出所有功能
export default {
  openLoginPage,
  openConsole,
  openAccountManagement,
  detectYiXiaoerLogin,
  checkLoginStatusByAPI,
  checkLoginStatusByBrowser,
  executeBrowserTask,
  waitForPageLoad,
  takeScreenshot,
  getAvailableTools
};
