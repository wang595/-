#!/usr/bin/env node
/**
 * Media Brain Zero - 账号扫描器
 * 功能：从蚁小二API获取已绑定的平台账号列表
 */

import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

// 蚁小二API配置
const YIXIAOER_API = 'https://www.yixiaoer.cn/api';
const YIXIAOER_API_KEY = process.env.YIXIAOER_API_KEY || '';

// 日志
function log(message, type = 'INFO') {
  const prefix = { INFO: '🔍', SUCCESS: '✅', WARN: '⚠️', ERROR: '❌', SCAN: '📡' }[type] || '📝';
  console.log(`${prefix} [Scanner] ${message}`);
}

// API请求封装
async function apiRequest(path, method = 'GET', body = null) {
  const url = path.startsWith('http') ? path : `${YIXIAOER_API}${path}`;
  const options = {
    method,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': YIXIAOER_API_KEY
    }
  };
  
  if (body) {
    options.body = JSON.stringify(body);
  }
  
  try {
    const response = await fetch(url, options);
    const text = await response.text();
    
    try {
      return JSON.parse(text);
    } catch {
      return { raw: text, statusCode: -1 };
    }
  } catch (error) {
    log(`API请求失败: ${error.message}`, 'ERROR');
    return { statusCode: -1, message: error.message };
  }
}

// 平台映射
const PLATFORM_MAP = {
  'douyin': '抖音',
  'xiaohongshu': '小红书',
  'weixinvideo': '视频号',
  'kuaishou': '快手',
  'zhihu': '知乎',
  'bilibili': 'B站',
  'toutiao': '今日头条',
  'weibo': '微博'
};

// 获取账号列表
export async function getAccounts() {
  log('正在获取账号列表...', 'SCAN');
  
  const result = await apiRequest('/v2/platform/accounts');
  
  if (result.statusCode !== 0) {
    log(`获取失败: ${result.message || '未知错误'}`, 'ERROR');
    return [];
  }
  
  const accounts = result.data || [];
  log(`获取到 ${accounts.length} 个账号`, 'SUCCESS');
  
  return accounts.map(acc => ({
    id: acc.platformAccountId || acc.id,
    name: acc.name || acc.platformAccountName || '未命名账号',
    platform: PLATFORM_MAP[acc.platform] || acc.platform || '未知平台',
    platformCode: acc.platform,
    fans: acc.fansCount || acc.fans_total || 0,
    contentCount: acc.contentCount || 0,
    avatar: acc.avatar || '',
    status: acc.status === 1 ? 'active' : 'inactive',
    level: acc.level || 'C', // A/B/C分级
    lastPublishTime: acc.lastPublishTime || null
  }));
}

// 获取单个账号详情
export async function getAccountDetail(accountId) {
  log(`正在获取账号 ${accountId} 详情...`, 'SCAN');
  
  const result = await apiRequest(`/v2/platform/accounts/${accountId}`);
  
  if (result.statusCode !== 0) {
    log(`获取详情失败: ${result.message || '未知错误'}`, 'ERROR');
    return null;
  }
  
  return result.data;
}

// 获取账号数据概览
export async function getAccountOverview(accountIds) {
  if (!accountIds || accountIds.length === 0) {
    return [];
  }
  
  log(`正在获取 ${accountIds.length} 个账号的数据概览...`, 'SCAN');
  
  const endTime = Date.now();
  const startTime = endTime - 7 * 24 * 60 * 60 * 1000; // 最近7天
  
  const result = await apiRequest('/contents/overviews', 'GET', null);
  
  // 构建查询参数
  const params = new URLSearchParams();
  accountIds.forEach(id => params.append('platformAccountIds', id));
  params.append('startTime', startTime);
  params.append('endTime', endTime);
  params.append('size', '20');
  
  const queryResult = await apiRequest(`/contents/overviews?${params.toString()}`);
  
  if (queryResult.statusCode !== 0) {
    log(`获取数据概览失败: ${queryResult.message || '未知错误'}`, 'ERROR');
    return [];
  }
  
  return queryResult.data?.data || [];
}

// 扫描所有账号（完整扫描）
export async function scanAccounts() {
  log('=== 开始全面账号扫描 ===', 'SCAN');
  
  // 1. 获取基础账号列表
  const accounts = await getAccounts();
  
  if (accounts.length === 0) {
    log('未发现任何已绑定的账号', 'WARN');
    return [];
  }
  
  // 2. 获取详细数据
  const accountIds = accounts.map(acc => acc.id);
  const overviews = await getAccountOverview(accountIds);
  
  // 3. 合并数据
  const enrichedAccounts = accounts.map(acc => {
    const overview = overviews.find(o => 
      o.platformAccountId === acc.id || 
      o.platformAccountId === acc.platformAccountId
    );
    
    return {
      ...acc,
      recentViews: overview?.statistic?.viewCount || 0,
      recentLikes: overview?.statistic?.diggCount || 0,
      recentComments: overview?.statistic?.commentCount || 0,
      recentShares: overview?.statistic?.shareCount || 0,
      recentContents: overview?.contentData || []
    };
  });
  
  // 4. 分类统计
  const stats = {
    total: enrichedAccounts.length,
    byPlatform: {},
    byStage: { cold: 0, growth: 0, mature: 0 }
  };
  
  enrichedAccounts.forEach(acc => {
    // 按平台统计
    if (!stats.byPlatform[acc.platform]) {
      stats.byPlatform[acc.platform] = 0;
    }
    stats.byPlatform[acc.platform]++;
    
    // 按阶段统计
    if (acc.fans >= 10000) stats.byStage.mature++;
    else if (acc.fans >= 1000) stats.byStage.growth++;
    else stats.byStage.cold++;
  });
  
  // 5. 打印扫描报告
  console.log(`
┌─────────────────────────────────────────────────────────────────┐
│                    📡 账号扫描报告                                │
├─────────────────────────────────────────────────────────────────┤
│  总账号数: ${stats.total}                                                   │
├─────────────────────────────────────────────────────────────────┤
│  📊 平台分布                                                     │
│  ${Object.entries(stats.byPlatform).map(([p, c]) => `  ${p}: ${c}个`).join('\n')}                                                       │
├─────────────────────────────────────────────────────────────────┤
│  📈 账号阶段                                                     │
│  冷启动: ${stats.byStage.cold}个  |  成长期: ${stats.byStage.growth}个  |  成熟期: ${stats.byStage.mature}个            │
└─────────────────────────────────────────────────────────────────┘
  `);
  
  return enrichedAccounts;
}

// 导出数据到文件
export function exportToFile(accounts, filepath) {
  try {
    writeFileSync(filepath, JSON.stringify(accounts, null, 2));
    log(`账号数据已导出到: ${filepath}`, 'SUCCESS');
    return true;
  } catch (error) {
    log(`导出失败: ${error.message}`, 'ERROR');
    return false;
  }
}

// 默认导出
export default {
  getAccounts,
  getAccountDetail,
  getAccountOverview,
  scanAccounts,
  exportToFile
};
