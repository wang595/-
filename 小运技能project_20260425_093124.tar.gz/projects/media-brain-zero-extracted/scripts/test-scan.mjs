#!/usr/bin/env node
/**
 * Media Brain Zero - 快速账号扫描测试
 */

import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

// 读取配置
const configPath = 'C:/Users/wlb/.qoderwork/media-matrix/yixiaoer_config.json';
const config = JSON.parse(readFileSync(configPath, 'utf-8'));

// 设置API Key
process.env.YIXIAOER_API_KEY = config.api_key;

const YIXIAOER_API = 'https://www.yixiaoer.cn/api';

async function main() {
  console.log('🔍 正在扫描蚁小二账号...\n');

  try {
    const response = await fetch(`${YIXIAOER_API}/v2/platform/accounts`, {
      headers: {
        'Authorization': config.api_key,
        'Content-Type': 'application/json'
      }
    });

    const data = await response.json();

    if (data.statusCode !== 0 && data.code !== 0) {
      console.log(`❌ API错误: ${data.message || data.msg || '未知错误'}`);
      console.log('完整响应:', JSON.stringify(data, null, 2));
      return;
    }

    const accounts = data.data || data.list || [];

    console.log(`\n✅ 成功获取 ${accounts.length} 个账号\n`);

    if (accounts.length > 0) {
      console.log('┌─────────────────────────────────────────────────────────────────┐');
      console.log('│                       📡 账号扫描报告                              │');
      console.log('├─────────────────────────────────────────────────────────────────┤');

      accounts.forEach((acc, i) => {
        const name = acc.name || acc.platformAccountName || '未命名';
        const platform = acc.platform || '未知平台';
        const fans = acc.fansCount || acc.fans_total || 0;
        console.log(`│  ${i + 1}. ${name.padEnd(15)} | ${platform.padEnd(8)} | 粉丝: ${String(fans).padStart(6)}        │`);
      });

      console.log('└─────────────────────────────────────────────────────────────────┘');
    } else {
      console.log('⚠️  暂未发现已绑定的账号，请在蚁小二后台添加账号后重试');
    }

  } catch (error) {
    console.log(`❌ 请求失败: ${error.message}`);
  }
}

main();
