/**
 * 素材库核心模块 (Material Library)
 * 
 * 功能：
 * - 桌面一个总文件夹「新媒体素材库」
 * - 每个账号一个专属文件夹「桢屿的专属素材库」
 * - 清晰的分类：待发布/已发布/企业素材
 * 
 * 作者：洞察 (Dongcha) - 效果追踪代理
 * 日期：2026-04-08
 */

import fs from 'fs/promises';
import path from 'path';
import { exec } from 'child_process';
import { promisify } from 'util';
import crypto from 'crypto';
import os from 'os';

const execAsync = promisify(exec);

class MaterialLib {
  /**
   * 构造函数
   * @param {Object} account - 账号配置对象
   */
  constructor(account) {
    this.account = account;
    this.accountId = account.id;
    this.accountName = account.name || '未知';
    this.platform = account.platform || '';
    
    // 桌面总文件夹
    this.desktopRoot = path.join(
      'C:', 'Users', os.userInfo().username, 'Desktop',
      '新媒体素材库'
    );
    
    // 账号专属文件夹
    this.libRoot = path.join(
      this.desktopRoot,
      `${this.accountName}的专属素材库`
    );
    
    // 素材库数据目录（实际存储位置）
    this.dataRoot = path.join(
      'C:', 'Users', os.userInfo().username, '.qoderwork', 
      'media-brain', 'accounts', this.accountId, 'materials'
    );
    
    // 子目录配置（清晰命名）
    this.subDirs = {
      pending: '📥待发布内容',      // AI生成，等待发布 ← 系统抓取这里
      pendingCovers: '📥待发布内容/封面图',
      pendingImages: '📥待发布内容/配图',
      pendingScripts: '📥待发布内容/文案脚本',
      published: '📦已发布归档',   // 发布成功的
      enterprise: '🏭企业素材',     // 真实素材 ← 使用者放这里
      enterpriseFactory: '🏭企业素材/厂区环境',
      enterpriseProduct: '🏭企业素材/产品展示',
      enterpriseTeam: '🏭企业素材/团队风采',
      enterpriseOther: '🏭企业素材/其他'
    };
    
    // 索引文件路径
    this.indexPath = path.join(this.libRoot, '📋素材索引.json');
    
    // 待发布队列文件（供系统抓取）
    this.pendingQueuePath = path.join(this.libRoot, '📥待发布内容', '_队列.json');
  }

  /**
   * 初始化素材库
   */
  async init() {
    console.log(`\n📦 初始化素材库: ${this.accountName}`);
    
    try {
      // 1. 创建目录结构
      await this._createDirectoryStructure();
      
      // 2. 创建桌面总文件夹和账号专属文件夹
      await this._createDesktopFolder();
      
      // 3. 初始化索引文件
      await this._initIndexFile();
      
      // 4. 创建使用说明
      await this._createReadme();
      
      console.log(`✅ 素材库初始化完成！`);
      console.log(`   📁 桌面总文件夹: ${this.desktopRoot}`);
      console.log(`   📁 账号专属: ${this.libRoot}`);
      
      return {
        success: true,
        desktopRoot: this.desktopRoot,
        accountFolder: this.libRoot
      };
    } catch (error) {
      console.error(`❌ 素材库初始化失败:`, error.message);
      throw error;
    }
  }

  /**
   * 创建完整的目录结构
   */
  async _createDirectoryStructure() {
    const dirs = [
      // 待发布内容
      path.join(this.libRoot, this.subDirs.pending),
      path.join(this.libRoot, this.subDirs.pendingCovers),
      path.join(this.libRoot, this.subDirs.pendingImages),
      path.join(this.libRoot, this.subDirs.pendingScripts),
      // 已发布归档
      path.join(this.libRoot, this.subDirs.published),
      path.join(this.libRoot, this.subDirs.published, this._getYearMonth()),
      // 企业素材
      path.join(this.libRoot, this.subDirs.enterprise),
      path.join(this.libRoot, this.subDirs.enterpriseFactory),
      path.join(this.libRoot, this.subDirs.enterpriseProduct),
      path.join(this.libRoot, this.subDirs.enterpriseTeam),
      path.join(this.libRoot, this.subDirs.enterpriseOther)
    ];

    for (const dir of dirs) {
      await fs.mkdir(dir, { recursive: true });
    }
  }

  /**
   * 在桌面创建文件夹
   */
  async _createDesktopFolder() {
    await fs.mkdir(this.desktopRoot, { recursive: true });
    await fs.mkdir(this.libRoot, { recursive: true });
    console.log(`   ✅ 桌面文件夹已创建`);
  }

  /**
   * 生成使用说明
   */
  async _createReadme() {
    const readmePath = path.join(this.libRoot, '📖使用说明.txt');
    const readmeContent = `
═══════════════════════════════════════════════════════════════
              ${this.accountName}的专属素材库
═══════════════════════════════════════════════════════════════

📅 创建日期：${new Date().toLocaleDateString('zh-CN')}
👤 所属账号：${this.accountName}
📱 平台：${this.platform || '未指定'}

───────────────────────────────────────────────────────────────
                      目录结构说明
───────────────────────────────────────────────────────────────

📥 待发布内容/  ← 【系统自动使用】
   ├── 封面图/    AI生成的封面图
   ├── 配图/      AI生成的正文配图
   └── 文案脚本/  AI生成的文案
   ↳ 系统会定期检查这个文件夹，找到内容后自动发布

📦 已发布归档/  ← 【发布成功的内容】
   └── 2026-04/  按年月分类的发布记录

🏭 企业素材/  ← 【请把真实素材放这里！】
   ├── 厂区环境/    厂区门口、车间、办公区域等实拍
   ├── 产品展示/    产品实物图、包装、细节特写等
   ├── 团队风采/    团队活动、员工工作、企业团建等
   └── 其他/        资质证书、客户案例、合作伙伴等

───────────────────────────────────────────────────────────────
                      使用方法
───────────────────────────────────────────────────────────────

👤 作为使用者：
   1. 把企业真实素材（照片、视频）放到「🏭企业素材」对应的文件夹
   2. AI生成内容时会自动参考这些真实素材
   3. 发布成功的内容会自动存入「📦已发布归档」

🤖 作为系统：
   1. 检查「📥待发布内容」文件夹
   2. 读取文案脚本和素材
   3. 发布后移动到「📦已发布归档」

───────────────────────────────────────────────────────────────
            由 Media Brain 素材库系统 管理
═══════════════════════════════════════════════════════════════
`;
    await fs.writeFile(readmePath, readmeContent, 'utf8');
    
    // 在企业素材子目录也放说明
    const enterpriseFolders = [
      { name: this.subDirs.enterpriseFactory, desc: '厂区环境', hint: '放厂区门口、车间、办公区域、生产线等实拍照片' },
      { name: this.subDirs.enterpriseProduct, desc: '产品展示', hint: '放产品实物图、包装、细节特写等' },
      { name: this.subDirs.enterpriseTeam, desc: '团队风采', hint: '放团队活动、员工工作、企业团建等照片' },
      { name: this.subDirs.enterpriseOther, desc: '其他素材', hint: '放资质证书、客户案例、合作伙伴等' }
    ];
    
    for (const folder of enterpriseFolders) {
      const readmePath = path.join(this.libRoot, folder.name, '📋说明.txt');
      await fs.writeFile(
        readmePath, 
        `【${folder.desc}】

${folder.hint}

将相关素材放在此文件夹中，AI生成内容时会自动参考这些真实素材，使内容更加真实可信。`,
        'utf8'
      );
    }
  }

  /**
   * 初始化素材索引文件
   */
  async _initIndexFile() {
    if (await this._fileExists(this.indexPath)) {
      const content = await fs.readFile(this.indexPath, 'utf8');
      this.index = JSON.parse(content);
    } else {
      this.index = {
        version: '2.0',
        accountId: this.accountId,
        accountName: this.accountName,
        platform: this.platform,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        materials: [],
        pending: [],  // 待发布队列
        published: [], // 已发布记录
        stats: {
          totalCount: 0,
          pendingCount: 0,
          publishedCount: 0,
          enterpriseCount: 0
        }
      };
      await this._saveIndex();
    }
  }

  /**
   * 保存到待发布队列（系统抓取点）
   * @param {Object} content - 内容数据
   * @param {string} title - 内容标题
   * @returns {Promise<Object>} 保存结果
   */
  async saveToPending(content, title) {
    const timestamp = Date.now();
    const safeTitle = (title || '内容').substring(0, 30).replace(/[^a-zA-Z0-9_\u4e00-\u9fa5]/g, '_');
    
    // 1. 保存封面图
    let coverRecord = null;
    if (content.coverBase64) {
      coverRecord = await this._saveImage(
        content.coverBase64, 
        `${safeTitle}_封面`,
        this.subDirs.pendingCovers
      );
    }
    
    // 2. 保存配图
    let imageRecords = [];
    if (content.images && Array.isArray(content.images)) {
      for (let i = 0; i < content.images.length; i++) {
        const img = content.images[i];
        if (img.base64) {
          const record = await this._saveImage(
            img.base64,
            `${safeTitle}_配图${i + 1}`,
            this.subDirs.pendingImages
          );
          imageRecords.push(record);
        }
      }
    }
    
    // 3. 保存文案脚本
    let scriptRecord = null;
    scriptRecord = await this._saveScript(content, title, safeTitle);
    
    // 4. 创建待发布条目
    const pendingItem = {
      id: this._generateId(),
      title: title,
      createdAt: new Date().toISOString(),
      cover: coverRecord ? { filename: coverRecord.filename, path: coverRecord.path } : null,
      images: imageRecords.map(r => ({ filename: r.filename, path: r.path })),
      script: scriptRecord ? { filename: scriptRecord.filename, path: scriptRecord.path } : null,
      status: 'pending',  // pending | publishing | published
      publishedAt: null,
      platformPostId: null
    };
    
    // 5. 添加到待发布队列
    this.index.pending.push(pendingItem);
    this.index.stats.pendingCount = this.index.pending.filter(p => p.status === 'pending').length;
    this.index.updatedAt = new Date().toISOString();
    await this._saveIndex();
    
    // 6. 更新待发布队列文件（供系统快速抓取）
    await this._updatePendingQueueFile();
    
    console.log(`   ✅ 已保存到待发布队列: ${title}`);
    console.log(`      待发布数量: ${this.index.stats.pendingCount}`);
    
    return pendingItem;
  }

  /**
   * 通用图片保存方法
   */
  async _saveImage(imageData, filename, relativeDir) {
    const timestamp = Date.now();
    const ext = this._getExtension(imageData) || '.jpg';
    const finalFilename = `${filename}${ext}`;
    
    const dirPath = path.join(this.libRoot, relativeDir);
    const filePath = path.join(dirPath, finalFilename);
    
    // 保存文件
    if (typeof imageData === 'string') {
      const base64Data = imageData.replace(/^data:image\/\w+;base64,/, '');
      await fs.writeFile(filePath, Buffer.from(base64Data, 'base64'));
    } else {
      await fs.writeFile(filePath, imageData);
    }
    
    const material = {
      id: this._generateId(),
      type: 'image',
      filename: finalFilename,
      relativePath: path.join(relativeDir, finalFilename),
      fullPath: filePath,
      source: 'ai-generated',
      size: (await fs.stat(filePath)).size,
      createdAt: new Date().toISOString(),
      status: 'pending',
      usedIn: [],
      publishedAt: null
    };
    
    // 添加 path 属性（兼容)
    material.path = material.relativePath;
    
    this.index.materials.push(material);
    this.index.stats.totalCount++;
    
    return material;
  }

  /**
   * 保存文案脚本
   */
  async _saveScript(content, title, safeTitle) {
    const timestamp = Date.now();
    const filename = `${safeTitle}_${timestamp}.json`;
    const relativePath = path.join(this.subDirs.pendingScripts, filename);
    const filePath = path.join(this.libRoot, relativePath);
    
    const scriptData = {
      title: title,
      body: content.body || content.text || '',
      tags: content.tags || [],
      _meta: {
        savedAt: new Date().toISOString(),
        accountId: this.accountId,
        accountName: this.accountName,
        source: 'ai-generated'
      }
    };
    
    await fs.writeFile(filePath, JSON.stringify(scriptData, null, 2), 'utf8');
    
    const material = {
      id: this._generateId(),
      type: 'script',
      filename: filename,
      relativePath: relativePath,
      fullPath: filePath,
      source: 'ai-generated',
      title: title,
      size: (await fs.stat(filePath)).size,
      createdAt: new Date().toISOString(),
      status: 'pending',
      usedIn: [],
      publishedAt: null
    };
    
    // 添加 path 属性（兼容)
    material.path = material.relativePath;
    
    this.index.materials.push(material);
    this.index.stats.totalCount++;
    
    return material;
  }

  /**
   * 更新待发布队列文件（供系统快速抓取）
   */
  async _updatePendingQueueFile() {
    const pendingItems = this.index.pending
      .filter(p => p.status === 'pending')
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    const items = pendingItems.map(item => {
      // 确保 images 数组存在且元素有效
      const validImages = (item.images || []).filter(img => img && img.path);
      
      return {
        id: item.id,
        title: item.title,
        createdAt: item.createdAt,
        cover: item.cover && item.cover.path ? path.join(this.libRoot, item.cover.path) : null,
        images: validImages.map(img => path.join(this.libRoot, img.path)),
        script: item.script && item.script.path ? path.join(this.libRoot, item.script.path) : null,
        // 同时提供相对路径（兼容不同读取方式）
        coverRelative: item.cover ? item.cover.path : null,
        imagesRelative: validImages.map(img => img.path),
        scriptRelative: item.script ? item.script.path : null,
        libRoot: this.libRoot
      };
    });
    
    const queueData = {
      updatedAt: new Date().toISOString(),
      count: items.length,
      items: items
    };
    
    await fs.writeFile(this.pendingQueuePath, JSON.stringify(queueData, null, 2), 'utf8');
    console.log(`   📋 待发布队列已更新: ${items.length} 条`);
  }

  /**
   * 获取待发布队列（系统抓取方法）
   * @returns {Promise<Array>} 待发布内容列表
   */
  async getPendingQueue() {
    // 优先从队列文件读取（快速）
    if (await this._fileExists(this.pendingQueuePath)) {
      const content = await fs.readFile(this.pendingQueuePath, 'utf8');
      const queueData = JSON.parse(content);
      
      // 过滤出pending状态的项目
      return queueData.items.filter(item => {
        const pendingItem = this.index.pending.find(p => p.id === item.id);
        return pendingItem && pendingItem.status === 'pending';
      });
    }
    
    // 备用：从索引读取
    return this.index.pending
      .filter(p => p.status === 'pending')
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  /**
   * 标记为发布中
   */
  async markAsPublishing(pendingId) {
    const item = this.index.pending.find(p => p.id === pendingId);
    if (item) {
      item.status = 'publishing';
      item.publishingAt = new Date().toISOString();
      await this._saveIndex();
      await this._updatePendingQueueFile();
    }
  }

  /**
   * 标记为已发布（归档）
   */
  async markAsPublished(pendingId, publishResult) {
    const item = this.index.pending.find(p => p.id === pendingId);
    if (!item) return null;
    
    const yearMonth = this._getYearMonth();
    const timestamp = Date.now();
    
    // 更新索引中的状态
    item.status = 'published';
    item.publishedAt = new Date().toISOString();
    item.platformPostId = publishResult?.data?.aweme_id || publishResult?.data?.id || null;
    item.publishUrl = publishResult?.data?.share_url || publishResult?.data?.video_url || null;
    
    // 移动到已发布归档
    this.index.published.push({
      ...item,
      archiveId: this._generateId(),
      archivePath: path.join(this.subDirs.published, yearMonth, `${timestamp}.json`)
    });
    
    // 更新统计
    this.index.stats.pendingCount = this.index.pending.filter(p => p.status === 'pending').length;
    this.index.stats.publishedCount = this.index.published.length;
    
    // 创建归档记录
    const archiveRecord = {
      archiveId: item.id,
      timestamp: timestamp,
      publishedAt: item.publishedAt,
      platform: this.platform,
      platformPostId: item.platformPostId,
      url: item.publishUrl,
      content: {
        title: item.title,
        cover: item.cover,
        images: item.images,
        script: item.script
      },
      originalPendingId: pendingId
    };
    
    const archiveDir = path.join(this.libRoot, this.subDirs.published, yearMonth);
    await fs.mkdir(archiveDir, { recursive: true });
    await fs.writeFile(
      path.join(archiveDir, `${timestamp}.json`),
      JSON.stringify(archiveRecord, null, 2),
      'utf8'
    );
    
    await this._saveIndex();
    await this._updatePendingQueueFile();
    
    // 移动素材文件（可选：保留原始位置或移动到归档）
    // 这里保持原位置，只更新索引
    
    console.log(`   ✅ 已归档: ${item.title}`);
    return archiveRecord;
  }

  /**
   * 获取企业真实素材（供AI生成时参考）
   */
  async getEnterpriseMaterials(category = null) {
    const materials = [];
    
    const categories = category 
      ? [{ name: category, path: path.join(this.libRoot, '🏭企业素材', category) }]
      : [
          { name: '厂区环境', path: path.join(this.libRoot, this.subDirs.enterpriseFactory) },
          { name: '产品展示', path: path.join(this.libRoot, this.subDirs.enterpriseProduct) },
          { name: '团队风采', path: path.join(this.libRoot, this.subDirs.enterpriseTeam) },
          { name: '其他', path: path.join(this.libRoot, this.subDirs.enterpriseOther) }
        ];
    
    for (const cat of categories) {
      if (await this._fileExists(cat.path)) {
        const files = await fs.readdir(cat.path, { withFileTypes: true });
        
        for (const file of files) {
          if (file.isFile() && !file.name.startsWith('📋')) {
            const filePath = path.join(cat.path, file.name);
            const stat = await fs.stat(filePath);
            const ext = path.extname(file.name).toLowerCase();
            
            if (['.jpg', '.jpeg', '.png', '.gif', '.mp4', '.mov', '.webp'].includes(ext)) {
              materials.push({
                filename: file.name,
                path: filePath,
                relativePath: path.relative(this.libRoot, filePath),
                category: cat.name,
                type: ['.mp4', '.mov'].includes(ext) ? 'video' : 'image',
                size: stat.size,
                modifiedAt: stat.mtime.toISOString(),
                source: 'enterprise'
              });
            }
          }
        }
      }
    }
    
    return materials;
  }

  /**
   * 获取已发布历史
   */
  async getPublishedHistory(limit = 20) {
    return this.index.published
      .sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt))
      .slice(0, limit);
  }

  /**
   * 获取统计信息
   */
  async getStats() {
    // 统计企业素材
    let enterpriseCount = 0;
    for (const cat of ['厂区环境', '产品展示', '团队风采', '其他']) {
      const catPath = path.join(this.libRoot, '🏭企业素材', cat);
      if (await this._fileExists(catPath)) {
        const files = await fs.readdir(catPath);
        enterpriseCount += files.filter(f => {
          const ext = path.extname(f).toLowerCase();
          return ['.jpg', '.jpeg', '.png', '.gif', '.mp4', '.mov', '.webp'].includes(ext);
        }).length;
      }
    }
    
    return {
      accountName: this.accountName,
      pendingCount: this.index.pending.filter(p => p.status === 'pending').length,
      publishingCount: this.index.pending.filter(p => p.status === 'publishing').length,
      publishedCount: this.index.published.length,
      enterpriseCount: enterpriseCount,
      totalCount: this.index.materials.length
    };
  }

  // ==================== 工具方法 ====================

  async _saveIndex() {
    await fs.writeFile(this.indexPath, JSON.stringify(this.index, null, 2), 'utf8');
  }

  async _fileExists(filePath) {
    try {
      await fs.access(filePath);
      return true;
    } catch {
      return false;
    }
  }

  _generateId() {
    return crypto.randomUUID ? crypto.randomUUID() : 
      `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  _getYearMonth() {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  }

  _getExtension(data) {
    if (typeof data === 'string' && data.startsWith('data:')) {
      const match = data.match(/^data:image\/(\w+);base64,/);
      if (match) {
        const ext = match[1];
        return ext === 'jpeg' ? '.jpg' : `.${ext}`;
      }
    }
    return null;
  }
}

/**
 * 素材库管理器
 */
class MaterialLibManager {
  constructor() {
    this.libs = new Map();
  }

  async initAll(accounts) {
    const results = [];
    
    for (const account of accounts) {
      if (account.status === 'active') {
        const lib = new MaterialLib(account);
        try {
          const result = await lib.init();
          this.libs.set(account.id, lib);
          results.push({ account: account.name, ...result });
        } catch (error) {
          results.push({ account: account.name, success: false, error: error.message });
        }
      }
    }
    
    return results;
  }

  getLib(accountId) {
    return this.libs.get(accountId);
  }

  async getAllStats() {
    const stats = {};
    for (const [accountId, lib] of this.libs) {
      stats[accountId] = await lib.getStats();
    }
    return stats;
  }
}

export { MaterialLib, MaterialLibManager };
export default MaterialLib;
