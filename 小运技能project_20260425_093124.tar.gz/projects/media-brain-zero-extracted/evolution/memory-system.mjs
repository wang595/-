#!/usr/bin/env node
/**
 * Media Brain Zero - 进化型记忆系统
 * 
 * 核心能力：
 * 1. 长记忆 - 记住每个账号的所有历史
 * 2. 上下文 - 理解当前讨论的背景
 * 3. 版本追踪 - 记录每个方案的变化
 * 4. 正向进化 - 从历史中学习，越做越好
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const MEMORY_DIR = join(__dirname, '..', 'evolution', 'memory');
const KNOWLEDGE_DIR = join(__dirname, '..', 'evolution', 'knowledge');

// 日志
function log(message, type = 'INFO') {
  const icons = {
    MEMORY: '🧠',
    SAVE: '💾',
    LOAD: '📖',
    EVOLVE: '🔄',
    COMPARE: '📊',
    SUCCESS: '✅',
    WARN: '⚠️',
    ERROR: '❌'
  };
  console.log(`${icons[type] || '📝'} [Memory] ${message}`);
}

/**
 * 确保目录存在
 */
function ensureDir(dir) {
  if (!existsSync(dir)) {
    mkdirSync(dir, { recursive: true });
  }
}

/**
 * 获取账号记忆目录
 */
function getAccountMemoryDir(accountId) {
  const dir = join(MEMORY_DIR, accountId);
  ensureDir(dir);
  return dir;
}

/**
 * 获取账号档案路径
 */
function getProfilePath(accountId) {
  return join(getAccountMemoryDir(accountId), 'profile.json');
}

/**
 * 获取历史方案目录
 */
function getHistoryDir(accountId) {
  const dir = join(getAccountMemoryDir(accountId), 'history');
  ensureDir(dir);
  return dir;
}

/**
 * 获取反馈目录
 */
function getFeedbackDir(accountId) {
  const dir = join(getAccountMemoryDir(accountId), 'feedback');
  ensureDir(dir);
  return dir;
}

/**
 * 获取效果目录
 */
function getResultsDir(accountId) {
  const dir = join(getAccountMemoryDir(accountId), 'results');
  ensureDir(dir);
  return dir;
}

/**
 * 获取方案版本列表
 */
function getPlanVersions(accountId) {
  const historyDir = getHistoryDir(accountId);
  if (!existsSync(historyDir)) return [];
  
  return readdirSync(historyDir)
    .filter(f => f.endsWith('.json'))
    .sort()
    .reverse(); // 最新版本在前
}

/**
 * 保存账号档案
 */
export function saveProfile(accountId, profile) {
  const path = getProfilePath(accountId);
  const data = {
    ...profile,
    updatedAt: new Date().toISOString(),
    version: (profile.version || 0) + 1
  };
  
  writeFileSync(path, JSON.stringify(data, null, 2), 'utf8');
  log(`档案已保存: ${accountId} (v${data.version})`, 'SAVE');
  return data;
}

/**
 * 加载账号档案
 */
export function loadProfile(accountId) {
  const path = getProfilePath(accountId);
  
  if (!existsSync(path)) {
    log(`档案不存在: ${accountId}`, 'WARN');
    return null;
  }
  
  try {
    const data = JSON.parse(readFileSync(path, 'utf8'));
    log(`档案已加载: ${accountId} (v${data.version})`, 'LOAD');
    return data;
  } catch (error) {
    log(`档案读取失败: ${error.message}`, 'ERROR');
    return null;
  }
}

/**
 * 保存方案版本
 */
export function savePlanVersion(accountId, plan, reason = 'initial') {
  const historyDir = getHistoryDir(accountId);
  const versions = getPlanVersions(accountId);
  const newVersion = versions.length + 1;
  const timestamp = new Date().toISOString().split('T')[0];
  const filename = `v${newVersion}_${timestamp}.json`;
  
  const versionData = {
    version: newVersion,
    timestamp,
    plan,
    reason, // 为什么要这样修改？
    context: plan._context || {}, // 生成这个方案的背景
    creator: plan._creator || 'system'
  };
  
  const path = join(historyDir, filename);
  writeFileSync(path, JSON.stringify(versionData, null, 2), 'utf8');
  log(`方案版本已保存: ${accountId}/${filename}`, 'SAVE');
  
  return versionData;
}

/**
 * 获取历史方案列表（带摘要）
 */
export function getPlanHistory(accountId) {
  const versions = getPlanVersions(accountId);
  
  return versions.map(filename => {
    const path = join(getHistoryDir(accountId), filename);
    const data = JSON.parse(readFileSync(path, 'utf8'));
    
    return {
      version: data.version,
      timestamp: data.timestamp,
      reason: data.reason,
      summary: {
        strategy: data.plan.strategy,
        dailyPosts: data.plan.dailyPosts,
        targetFans: data.plan.targetFans,
        stage: data.plan.stageLabel
      }
    };
  });
}

/**
 * 获取最新方案
 */
export function getLatestPlan(accountId) {
  const versions = getPlanVersions(accountId);
  
  if (versions.length === 0) {
    return null;
  }
  
  const latestVersion = versions[0]; // 已经倒序
  const path = join(getHistoryDir(accountId), latestVersion);
  const data = JSON.parse(readFileSync(path, 'utf8'));
  
  return data;
}

/**
 * 获取方案对比
 */
export function comparePlans(accountId, version1, version2) {
  const historyDir = getHistoryDir(accountId);
  
  const v1Path = join(historyDir, version1);
  const v2Path = join(historyDir, version2);
  
  if (!existsSync(v1Path) || !existsSync(v2Path)) {
    return null;
  }
  
  const v1 = JSON.parse(readFileSync(v1Path, 'utf8'));
  const v2 = JSON.parse(readFileSync(v2Path, 'utf8'));
  
  // 找出变化点
  const changes = [];
  
  // 策略变化
  if (v1.plan.strategy !== v2.plan.strategy) {
    changes.push({
      field: 'strategy',
      from: v1.plan.strategy,
      to: v2.plan.strategy,
      reason: `版本${v2.version}调整为: ${v2.reason}`
    });
  }
  
  // 发布频率变化
  if (v1.plan.dailyPosts !== v2.plan.dailyPosts) {
    changes.push({
      field: 'dailyPosts',
      from: v1.plan.dailyPosts,
      to: v2.plan.dailyPosts,
      reason: `版本${v2.version}调整: ${v2.reason}`
    });
  }
  
  // 目标变化
  if (v1.plan.targetFans !== v2.plan.targetFans) {
    changes.push({
      field: 'targetFans',
      from: v1.plan.targetFans,
      to: v2.plan.targetFans,
      reason: `版本${v2.version}调整: ${v2.reason}`
    });
  }
  
  return {
    v1: { version: v1.version, timestamp: v1.timestamp },
    v2: { version: v2.version, timestamp: v2.timestamp },
    changes
  };
}

/**
 * 保存客户反馈
 */
export function saveFeedback(accountId, feedback) {
  const feedbackDir = getFeedbackDir(accountId);
  const timestamp = new Date().toISOString().split('T')[0];
  const filename = `feedback_${timestamp}.json`;
  
  const feedbackData = {
    timestamp: new Date().toISOString(),
    ...feedback
  };
  
  const path = join(feedbackDir, filename);
  writeFileSync(path, JSON.stringify(feedbackData, null, 2), 'utf8');
  log(`反馈已保存: ${accountId}/${filename}`, 'SAVE');
  
  return feedbackData;
}

/**
 * 获取所有反馈
 */
export function getAllFeedback(accountId) {
  const feedbackDir = getFeedbackDir(accountId);
  
  if (!existsSync(feedbackDir)) {
    return [];
  }
  
  return readdirSync(feedbackDir)
    .filter(f => f.endsWith('.json'))
    .sort()
    .reverse()
    .map(filename => {
      const path = join(feedbackDir, filename);
      return JSON.parse(readFileSync(path, 'utf8'));
    });
}

/**
 * 保存执行效果
 */
export function saveResults(accountId, results) {
  const resultsDir = getResultsDir(accountId);
  const timestamp = new Date().toISOString().split('T')[0];
  const filename = `metrics_${timestamp}.json`;
  
  const resultsData = {
    timestamp: new Date().toISOString(),
    date: timestamp,
    ...results
  };
  
  const path = join(resultsDir, filename);
  writeFileSync(path, JSON.stringify(resultsData, null, 2), 'utf8');
  log(`效果数据已保存: ${accountId}/${filename}`, 'SAVE');
  
  return resultsData;
}

/**
 * 获取效果趋势
 */
export function getResultsTrend(accountId, days = 7) {
  const resultsDir = getResultsDir(accountId);
  
  if (!existsSync(resultsDir)) {
    return [];
  }
  
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - days);
  
  return readdirSync(resultsDir)
    .filter(f => f.endsWith('.json'))
    .sort()
    .map(filename => {
      const path = join(resultsDir, filename);
      return JSON.parse(readFileSync(path, 'utf8'));
    })
    .filter(r => new Date(r.date) >= cutoffDate)
    .sort((a, b) => new Date(a.date) - new Date(b.date));
}

/**
 * 获取账号的完整记忆上下文
 */
export function getAccountContext(accountId) {
  const profile = loadProfile(accountId);
  const latestPlan = getLatestPlan(accountId);
  const feedback = getAllFeedback(accountId);
  const trend = getResultsTrend(accountId, 30);
  const history = getPlanHistory(accountId);
  
  // 构建上下文摘要
  const context = {
    accountId,
    summary: profile ? {
      name: profile.name,
      platform: profile.platform,
      currentFans: profile.fans,
      stage: profile.stageLabel
    } : null,
    
    // 当前方案
    currentPlan: latestPlan ? {
      version: latestPlan.version,
      timestamp: latestPlan.timestamp,
      strategy: latestPlan.plan.strategy,
      dailyPosts: latestPlan.plan.dailyPosts,
      targetFans: latestPlan.plan.targetFans
    } : null,
    
    // 最近的反馈
    recentFeedback: feedback.slice(0, 3).map(f => ({
      date: f.timestamp,
      type: f.type,
      content: f.content?.substring(0, 100) + (f.content?.length > 100 ? '...' : '')
    })),
    
    // 效果趋势摘要
    trendSummary: trend.length > 0 ? {
      period: `${trend[0].date} ~ ${trend[trend.length - 1].date}`,
      dataPoints: trend.length,
      avgViews: Math.round(trend.reduce((sum, t) => sum + (t.views || 0), 0) / trend.length),
      avgLikes: Math.round(trend.reduce((sum, t) => sum + (t.likes || 0), 0) / trend.length),
      fanGrowth: trend.length > 1 ? trend[trend.length - 1].fans - trend[0].fans : 0
    } : null,
    
    // 方案演进历史
    evolution: history.slice(0, 5).map(h => ({
      version: h.version,
      date: h.timestamp,
      reason: h.reason
    }))
  };
  
  return context;
}

/**
 * 获取所有账号的记忆概览
 */
export function getAllAccountsSummary() {
  ensureDir(MEMORY_DIR);
  
  const accountDirs = readdirSync(MEMORY_DIR).filter(f => {
    return existsSync(join(MEMORY_DIR, f, 'profile.json'));
  });
  
  return accountDirs.map(accountId => {
    const profile = loadProfile(accountId);
    const history = getPlanVersions(accountId);
    const trend = getResultsTrend(accountId, 7);
    
    return {
      accountId,
      name: profile?.name || '未知',
      platform: profile?.platform || '未知',
      currentFans: profile?.fans || 0,
      stage: profile?.stageLabel || '未知',
      planVersions: history.length,
      latestResult: trend.length > 0 ? trend[trend.length - 1] : null
    };
  });
}

/**
 * 删除账号记忆（谨慎使用）
 */
export function deleteAccountMemory(accountId) {
  const accountDir = join(MEMORY_DIR, accountId);
  if (existsSync(accountDir)) {
    // 使用 rm 命令删除目录
    import('child_process').then(({ execSync }) => {
      execSync(`rm -rf "${accountDir}"`);
      log(`记忆已删除: ${accountId}`, 'MEMORY');
    });
    return true;
  }
  return false;
}

// 导出所有功能
export default {
  // 档案管理
  saveProfile,
  loadProfile,
  
  // 方案版本
  savePlanVersion,
  getPlanHistory,
  getLatestPlan,
  comparePlans,
  
  // 反馈
  saveFeedback,
  getAllFeedback,
  
  // 效果追踪
  saveResults,
  getResultsTrend,
  
  // 上下文
  getAccountContext,
  getAllAccountsSummary,
  
  // 工具
  deleteAccountMemory,
  getAccountMemoryDir
};
