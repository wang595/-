#!/usr/bin/env node
/**
 * Media Brain Zero - 进化引擎
 *
 * 核心能力：
 * 1. 学习成功模式 - 从数据好的方案中学习
 * 2. 识别失败信号 - 发现效果下降的原因
 * 3. 自动优化建议 - 提出改进方案
 * 4. 进化决策 - 决定是否需要调整策略
 */

import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const KNOWLEDGE_DIR = join(__dirname, '..', 'evolution', 'knowledge');

// API配置
const CONFIG = {
  DEEPSEEK_API_KEY: process.env.DEEPSEEK_API_KEY || '',
  DEEPSEEK_API: 'https://api.deepseek.com/chat/completions'
};

// 日志
function log(message, type = 'INFO') {
  const icons = {
    LEARN: '📚',
    EVOLVE: '🔄',
    ANALYZE: '🔍',
    SUCCESS: '✅',
    WARN: '⚠️',
    ERROR: '❌',
    AI: '🧠'
  };
  console.log(`${icons[type] || '📝'} [Evolution] ${message}`);
}

// 确保知识目录存在
function ensureKnowledgeDir() {
  if (!existsSync(KNOWLEDGE_DIR)) {
    mkdirSync(KNOWLEDGE_DIR, { recursive: true });
  }
}

/**
 * 调用DeepSeek API
 */
async function callDeepSeek(prompt, temperature = 0.7) {
  if (!CONFIG.DEEPSEEK_API_KEY) {
    log('未配置DeepSeek API Key', 'WARN');
    return null;
  }

  try {
    const response = await fetch(CONFIG.DEEPSEEK_API, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${CONFIG.DEEPSEEK_API_KEY}`
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [
          {
            role: 'system',
            content: `你是专业的新媒体运营顾问，擅长从历史数据中学习并提出优化建议。
你的分析要基于数据，结论要具体可执行。`
          },
          { role: 'user', content: prompt }
        ],
        temperature
      })
    });

    const data = await response.json();
    return data.choices?.[0]?.message?.content || null;
  } catch (error) {
    log(`AI调用失败: ${error.message}`, 'ERROR');
    return null;
  }
}

/**
 * 保存学习成果
 */
function saveLearnedPattern(type, pattern) {
  ensureKnowledgeDir();
  const path = join(KNOWLEDGE_DIR, `${type}_patterns.json`);

  let patterns = {};
  if (existsSync(path)) {
    patterns = JSON.parse(readFileSync(path, 'utf8'));
  }

  patterns[pattern.id] = {
    ...pattern,
    learnedAt: new Date().toISOString()
  };

  writeFileSync(path, JSON.stringify(patterns, null, 2), 'utf8');
  log(`学习成果已保存: ${type}/${pattern.id}`, 'LEARN');
}

/**
 * 获取已学习的模式
 */
function getLearnedPatterns(type) {
  const path = join(KNOWLEDGE_DIR, `${type}_patterns.json`);

  if (!existsSync(path)) {
    return [];
  }

  return Object.values(JSON.parse(readFileSync(path, 'utf8')));
}

/**
 * 分析效果变化趋势
 */
export function analyzeTrend(results) {
  if (results.length < 2) {
    return {
      trend: 'insufficient_data',
      message: '数据点不足，无法分析趋势'
    };
  }

  // 计算关键指标的变化
  const firstHalf = results.slice(0, Math.floor(results.length / 2));
  const secondHalf = results.slice(Math.floor(results.length / 2));

  const avg = (arr, key) => arr.reduce((sum, r) => sum + (r[key] || 0), 0) / arr.length;

  const metrics = ['views', 'likes', 'comments', 'shares', 'fans'];
  const analysis = {};

  let positiveCount = 0;
  let negativeCount = 0;

  for (const metric of metrics) {
    const before = avg(firstHalf, metric);
    const after = avg(secondHalf, metric);
    const change = before > 0 ? ((after - before) / before * 100).toFixed(1) : 0;

    analysis[metric] = {
      before: Math.round(before),
      after: Math.round(after),
      change: parseFloat(change),
      direction: change > 5 ? 'up' : change < -5 ? 'down' : 'stable'
    };

    if (change > 5) positiveCount++;
    if (change < -5) negativeCount++;
  }

  // 综合判断
  let overallTrend;
  if (positiveCount > negativeCount && positiveCount >= 2) {
    overallTrend = 'improving';
  } else if (negativeCount > positiveCount && negativeCount >= 2) {
    overallTrend = 'declining';
  } else {
    overallTrend = 'stable';
  }

  return {
    trend: overallTrend,
    metrics: analysis,
    summary: generateTrendSummary(overallTrend, analysis)
  };
}

/**
 * 生成趋势摘要
 */
function generateTrendSummary(trend, metrics) {
  const summaries = {
    improving: `📈 整体向好！`,
    declining: `📉 需要关注`,
    stable: `➡️ 基本稳定`
  };

  let details = [];
  for (const [key, data] of Object.entries(metrics)) {
    if (data.direction === 'up') {
      details.push(`${key}上升${data.change}%`);
    } else if (data.direction === 'down') {
      details.push(`${key}下降${Math.abs(data.change)}%`);
    }
  }

  return {
    status: summaries[trend],
    details: details.slice(0, 3)
  };
}

/**
 * 识别成功模式
 */
export async function learnFromSuccess(accountId, results, plan) {
  log(`正在学习成功模式: ${accountId}`, 'LEARN');

  // 分析哪些指标表现好
  const trend = analyzeTrend(results);

  if (trend.trend !== 'improving') {
    log('无明显成功模式可学习', 'ANALYZE');
    return null;
  }

  // 提取成功要素
  const successFactors = [];

  // 检查内容类型
  if (results.some(r => r.topContentType === '干货')) {
    successFactors.push({
      type: 'content_type',
      value: '干货',
      impact: '高互动率'
    });
  }

  // 检查发布时间
  const bestPerforming = results.reduce((best, r) =>
    (r.likes / r.posts) > (best.likes / best.posts) ? r : best
  , results[0]);

  if (bestPerforming.publishTime) {
    successFactors.push({
      type: 'publish_time',
      value: bestPerforming.publishTime,
      impact: '最佳互动时段'
    });
  }

  // 保存成功模式
  const pattern = {
    id: `${accountId}_${Date.now()}`,
    accountId,
    trend,
    factors: successFactors,
    planSnapshot: {
      strategy: plan.strategy,
      dailyPosts: plan.dailyPosts,
      topics: plan.topics,
      stage: plan.stage
    }
  };

  saveLearnedPattern('success', pattern);

  return {
    pattern,
    insight: `发现${successFactors.length}个成功要素`,
    recommendations: successFactors.map(f =>
      `建议继续采用${f.type === 'content_type' ? '内容类型' : '发布时间'}: ${f.value}`
    )
  };
}

/**
 * 识别失败信号
 */
export async function detectFailureSignals(accountId, results, plan) {
  log(`正在检测失败信号: ${accountId}`, 'ANALYZE');

  const trend = analyzeTrend(results);

  if (trend.trend !== 'declining') {
    log('无明显失败信号', 'ANALYZE');
    return null;
  }

  // 分析可能的原因
  const signals = [];

  // 检查是否内容过多
  const recentResults = results.slice(-3);
  const avgPostsPerDay = recentResults.reduce((sum, r) => sum + (r.posts || 0), 0) / recentResults.length;

  if (avgPostsPerDay > 2) {
    signals.push({
      type: 'over_posting',
      severity: 'warning',
      message: '发布过于频繁，可能导致粉丝疲劳',
      data: `日均发布${avgPostsPerDay.toFixed(1)}条`
    });
  }

  // 检查互动率下降
  const firstHalf = results.slice(0, Math.floor(results.length / 2));
  const secondHalf = results.slice(Math.floor(results.length / 2));
  const beforeRate = firstHalf.reduce((sum, r) => sum + ((r.likes + r.comments) / (r.views || 1)), 0) / firstHalf.length;
  const afterRate = secondHalf.reduce((sum, r) => sum + ((r.likes + r.comments) / (r.views || 1)), 0) / secondHalf.length;

  if (afterRate < beforeRate * 0.7) {
    signals.push({
      type: 'engagement_drop',
      severity: 'critical',
      message: '互动率显著下降',
      data: `从${(beforeRate * 100).toFixed(1)}%降至${(afterRate * 100).toFixed(1)}%`
    });
  }

  // 保存失败信号
  const signalRecord = {
    id: `${accountId}_${Date.now()}`,
    accountId,
    timestamp: new Date().toISOString(),
    trend,
    signals,
    planContext: {
      strategy: plan.strategy,
      stage: plan.stage
    }
  };

  saveLearnedPattern('failure', signalRecord);

  return {
    signalRecord,
    urgency: signals.some(s => s.severity === 'critical') ? 'high' : 'medium',
    recommendations: signals.map(s =>
      `${s.severity === 'critical' ? '🔴' : '🟡'} ${s.message}: ${s.data}`
    )
  };
}

/**
 * 生成进化建议（AI驱动）
 */
export async function generateEvolutionSuggestions(accountId, context) {
  log(`正在生成进化建议: ${accountId}`, 'EVOLVE');

  const prompt = `分析以下账号的运营数据，生成优化建议：

账号信息：
- 名称：${context.summary?.name || '未知'}
- 平台：${context.summary?.platform || '未知'}
- 当前阶段：${context.summary?.stage || '未知'}
- 当前粉丝：${context.summary?.currentFans || 0}

当前方案：
- 策略：${context.currentPlan?.strategy || '无'}
- 发布频率：${context.currentPlan?.dailyPosts || 0}条/天
- 目标粉丝：${context.currentPlan?.targetFans || 0}

${context.trendSummary ? `
最近30天效果：
- 数据周期：${context.trendSummary.period}
- 平均曝光：${context.trendSummary.avgViews}
- 平均点赞：${context.trendSummary.avgLikes}
- 粉丝增长：${context.trendSummary.fanGrowth > 0 ? '+' : ''}${context.trendSummary.fanGrowth}
` : '（无效果数据）'}

${context.recentFeedback?.length > 0 ? `
客户反馈：
${context.recentFeedback.map(f => `- ${f.type}: ${f.content}`).join('\n')}
` : ''}

${context.evolution?.length > 0 ? `
方案演进历史：
${context.evolution.map(e => `- v${e.version} (${e.date}): ${e.reason}`).join('\n')}
` : ''}

请分析：
1. 当前方案的问题是什么？
2. 应该如何调整？
3. 预期效果是什么？

输出JSON格式：
{
  "diagnosis": "问题诊断",
  "suggestions": [
    {
      "change": "具体改变",
      "reason": "为什么要这样改",
      "expectedImpact": "预期效果"
    }
  ],
  "riskLevel": "low/medium/high"
}`;

  const response = await callDeepSeek(prompt);

  if (response) {
    try {
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
    } catch (e) {
      log('解析AI响应失败', 'ERROR');
    }
  }

  // 如果AI调用失败，返回基于规则的默认建议
  return generateRuleBasedSuggestions(context);
}

/**
 * 基于规则生成建议
 */
function generateRuleBasedSuggestions(context) {
  const suggestions = [];

  // 检查粉丝增长
  if (context.trendSummary && context.trendSummary.fanGrowth < 10) {
    suggestions.push({
      change: '增加蹭热点频率',
      reason: '粉丝增长缓慢，需要借助热点提升曝光',
      expectedImpact: '曝光提升50%'
    });
  }

  // 检查发布频率
  if (context.currentPlan?.dailyPosts < 1) {
    suggestions.push({
      change: '提升发布频率至日更',
      reason: '新账号需要更多内容积累',
      expectedImpact: '账号权重提升'
    });
  }

  // 检查内容方向
  if (context.currentPlan?.strategy?.includes('品牌')) {
    suggestions.push({
      change: '增加互动性内容',
      reason: '成熟账号需要粉丝粘性',
      expectedImpact: '评论率提升'
    });
  }

  return {
    diagnosis: '基于数据分析的优化建议',
    suggestions,
    riskLevel: 'medium'
  };
}

/**
 * 决定是否需要进化
 */
export async function shouldEvolve(accountId, context) {
  log(`评估是否需要进化: ${accountId}`, 'EVOLVE');

  // 检查条件
  const needsEvolution = {
    hasNewFeedback: context.recentFeedback?.length > 0,
    hasDecliningTrend: context.trendSummary?.fanGrowth < 0,
    noRecentPlan: !context.currentPlan,
    hasNewVersion: false,
    noImprovement: false
  };

  // 检查是否长期无改善
  if (context.trendSummary && context.evolution?.length >= 2) {
    needsEvolution.noImprovement = context.trendSummary.fanGrowth < 5;
  }

  // 计算进化紧迫度
  let urgency = 'none';

  if (needsEvolution.hasDecliningTrend) {
    urgency = 'high';
  } else if (needsEvolution.hasNewFeedback) {
    urgency = 'medium';
  } else if (needsEvolution.noImprovement) {
    urgency = 'medium';
  } else if (needsEvolution.noRecentPlan) {
    urgency = 'low';
  }

  // 生成决策说明
  const decision = {
    shouldEvolve: urgency !== 'none',
    urgency,
    triggers: Object.entries(needsEvolution)
      .filter(([_, value]) => value)
      .map(([key]) => key),
    nextAction: getNextAction(urgency, context)
  };

  return decision;
}

/**
 * 获取下一步行动
 */
function getNextAction(urgency, context) {
  switch (urgency) {
    case 'high':
      return '立即生成优化方案并实施';
    case 'medium':
      return '生成建议方案，等待确认后实施';
    case 'low':
      return '给出优化建议，可选择性采纳';
    default:
      return '当前方案运行良好，无需调整';
  }
}

/**
 * 执行进化
 */
export async function executeEvolution(accountId, newPlan, reason) {
  log(`执行进化: ${accountId}`, 'EVOLVE');

  // 这里会调用 memory-system 来保存新方案版本
  const { savePlanVersion, loadProfile } = await import('./memory-system.mjs');

  // 更新档案
  const profile = loadProfile(accountId);
  if (profile) {
    profile.fans = newPlan.currentFans || profile.fans;
    profile.stage = newPlan.stage || profile.stage;
  }

  // 保存新版本方案
  const versionData = await savePlanVersion(accountId, newPlan, reason);

  // 记录进化事件
  saveEvolutionEvent(accountId, {
    type: 'plan_evolution',
    from: newPlan._previousVersion,
    to: versionData.version,
    reason,
    timestamp: new Date().toISOString()
  });

  return {
    success: true,
    newVersion: versionData.version,
    message: `已更新至v${versionData.version}版本`
  };
}

/**
 * 保存进化事件
 */
function saveEvolutionEvent(accountId, event) {
  ensureKnowledgeDir();
  const path = join(KNOWLEDGE_DIR, 'evolution_events.json');

  let events = [];
  if (existsSync(path)) {
    events = JSON.parse(readFileSync(path, 'utf8'));
  }

  events.push({
    accountId,
    ...event
  });

  // 只保留最近100条
  if (events.length > 100) {
    events = events.slice(-100);
  }

  writeFileSync(path, JSON.stringify(events, null, 2), 'utf8');
}

/**
 * 获取进化历史
 */
export function getEvolutionHistory(accountId) {
  const path = join(KNOWLEDGE_DIR, 'evolution_events.json');

  if (!existsSync(path)) {
    return [];
  }

  const events = JSON.parse(readFileSync(path, 'utf8'));
  return events.filter(e => e.accountId === accountId);
}

/**
 * 获取全局学习洞察
 */
export function getGlobalInsights() {
  ensureKnowledgeDir();

  const successPatterns = getLearnedPatterns('success');
  const failurePatterns = getLearnedPatterns('failure');

  // 统计常见的成功因素
  const successFactors = {};
  for (const pattern of successPatterns) {
    for (const factor of pattern.factors || []) {
      const key = `${factor.type}:${factor.value}`;
      successFactors[key] = (successFactors[key] || 0) + 1;
    }
  }

  // 统计常见的失败信号
  const failureTypes = {};
  for (const pattern of failurePatterns) {
    for (const signal of pattern.signals || []) {
      failureTypes[signal.type] = (failureTypes[signal.type] || 0) + 1;
    }
  }

  return {
    totalSuccessPatterns: successPatterns.length,
    totalFailurePatterns: failurePatterns.length,
    topSuccessFactors: Object.entries(successFactors)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([key, count]) => {
        const [type, value] = key.split(':');
        return { type, value, count };
      }),
    commonFailures: Object.entries(failureTypes)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([type, count]) => ({ type, count })),
    insights: generateGlobalInsights(successPatterns, failurePatterns)
  };
}

/**
 * 生成全局洞察
 */
function generateGlobalInsights(successPatterns, failurePatterns) {
  const insights = [];

  // 从成功中学习
  if (successPatterns.length >= 3) {
    insights.push({
      category: '成功经验',
      content: `已从${successPatterns.length}个成功案例中学习到优化经验`
    });
  }

  // 从失败中预防
  if (failurePatterns.length >= 3) {
    const commonIssue = Object.entries(
      failurePatterns.reduce((acc, p) => {
        for (const s of p.signals || []) {
          acc[s.type] = (acc[s.type] || 0) + 1;
        }
        return acc;
      }, {})
    ).sort((a, b) => b[1] - a[1])[0];

    if (commonIssue) {
      insights.push({
        category: '预防重点',
        content: `需特别注意${commonIssue[0]}问题，已在${commonIssue[1]}个案例中出现`
      });
    }
  }

  return insights;
}

// 默认导出
export default {
  // 趋势分析
  analyzeTrend,

  // 学习能力
  learnFromSuccess,
  detectFailureSignals,

  // 进化决策
  generateEvolutionSuggestions,
  shouldEvolve,
  executeEvolution,

  // 历史
  getEvolutionHistory,
  getGlobalInsights
};
