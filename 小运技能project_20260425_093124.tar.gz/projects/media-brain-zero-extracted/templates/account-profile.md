# 📋 账号档案

**账号名称：** {{name}}
**运营平台：** {{platform}}
**创建日期：** {{createdAt}}

---

## 📊 基础信息

| 项目 | 内容 |
|------|------|
| 账号ID | {{id}} |
| 账号名称 | {{name}} |
| 平台 | {{platform}} |
| 当前粉丝 | {{fans}} |
| 内容总数 | {{contentCount}} |
| 账号阶段 | {{stage}} |

---

## 🎯 运营定位

**定位描述：** {{position}}

**内容主题：**
{{#each themes}}
- {{this}}
{{/each}}

---

## 📈 数据概览

### 近7天数据

| 指标 | 数值 | 趋势 |
|------|------|------|
| 总曝光 | {{recentViews}} | {{viewsTrend}} |
| 总点赞 | {{recentLikes}} | {{likesTrend}} |
| 总评论 | {{recentComments}} | {{commentsTrend}} |
| 总转发 | {{recentShares}} | {{sharesTrend}} |

### 互动数据

| 指标 | 数值 | 行业对比 |
|------|------|----------|
| 点赞率 | {{likeRate}}% | {{likeRateCompare}} |
| 评论率 | {{commentRate}}% | {{commentRateCompare}} |
| 转发率 | {{shareRate}}% | {{shareRateCompare}} |

---

## 🔍 账号诊断

### 优势
{{#each strengths}}
- {{this}}
{{/each}}

### 劣势
{{#each weaknesses}}
- {{this}}
{{/each}}

### 机会
{{#each opportunities}}
- {{this}}
{{/each}}

### 威胁
{{#each threats}}
- {{this}}
{{/each}}

---

## 📅 运营历史

{{#each history}}
### {{date}}
- 发布：{{posts}} 条
- 亮点：{{highlight}}
{{/each}}

---

*档案生成时间：{{generatedAt}}*
