# 📊 运营日报

**账号：** {{accountName}}
**日期：** {{date}}
**平台：** {{platform}}

---

## 📈 今日数据

| 指标 | 今日 | 昨日 | 变化 |
|------|------|------|------|
| 发布数量 | {{todayPosts}} | {{yesterdayPosts}} | {{postsChange}} |
| 总曝光 | {{todayViews}} | {{yesterdayViews}} | {{viewsChange}} |
| 点赞数 | {{todayLikes}} | {{yesterdayLikes}} | {{likesChange}} |
| 评论数 | {{todayComments}} | {{yesterdayComments}} | {{commentsChange}} |
| 新增粉丝 | {{todayFans}} | {{yesterdayFans}} | {{fansChange}} |

---

## 📋 今日发布内容

{{#each todayContents}}
### {{title}}
- 发布时间：{{time}}
- 曝光量：{{views}}
- 点赞：{{likes}} | 评论：{{comments}} | 转发：{{shares}}
{{/each}}

---

## 🔥 热点追踪

**蹭热点：** {{hotspotUsed}}
- {{hotspotName}}

---

## ⚠️ 问题与处理

{{#if issues}}
{{issues}}
{{else}}
今日无异常，运行正常。
{{/if}}

---

## 📅 明日计划

- 发布时段：{{tomorrowTimes}}
- 预计发布：{{tomorrowPosts}} 条
- 内容方向：{{tomorrowDirection}}

---

*📅 报告生成时间：{{generatedAt}}*
